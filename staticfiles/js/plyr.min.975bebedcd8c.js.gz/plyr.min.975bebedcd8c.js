"object" == typeof navigator && function(e, t) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define("Plyr", t) : e.Plyr = t()
}(this, function() {
    "use strict";
    var e = function(e) {
            return null != e ? e.constructor : null
        },
        t = function(e, t) {
            return Boolean(e && t && e instanceof t)
        },
        i = function(e) {
            return null == e
        },
        n = function(t) {
            return e(t) === Object
        },
        s = function(t) {
            return e(t) === String
        },
        a = function(e) {
            return Array.isArray(e)
        },
        o = function(e) {
            return t(e, NodeList)
        },
        r = function(e) {
            return i(e) || (s(e) || a(e) || o(e)) && !e.length || n(e) && !Object.keys(e).length
        },
        l = {
            nullOrUndefined: i,
            object: n,
            number: function(t) {
                return e(t) === Number && !Number.isNaN(t)
            },
            string: s,
            boolean: function(t) {
                return e(t) === Boolean
            },
            function: function(t) {
                return e(t) === Function
            },
            array: a,
            weakMap: function(e) {
                return t(e, WeakMap)
            },
            nodeList: o,
            element: function(e) {
                return t(e, Element)
            },
            textNode: function(t) {
                return e(t) === Text
            },
            event: function(e) {
                return t(e, Event)
            },
            keyboardEvent: function(e) {
                return t(e, KeyboardEvent)
            },
            cue: function(e) {
                return t(e, window.TextTrackCue) || t(e, window.VTTCue)
            },
            track: function(e) {
                return t(e, TextTrack) || !i(e) && s(e.kind)
            },
            url: function(e) {
                if (t(e, window.URL)) return !0;
                var i = e;
                e.startsWith("http://") && e.startsWith("https://") || (i = "http://" + e);
                try {
                    return !r(new URL(i).hostname)
                } catch (e) {
                    return !1
                }
            },
            empty: r
        },
        c = function() {
            var e = !1;
            try {
                var t = Object.defineProperty({}, "passive", {
                    get: function() {
                        return e = !0, null
                    }
                });
                window.addEventListener("test", null, t), window.removeEventListener("test", null, t)
            } catch (e) {}
            return e
        }();

    function u(e, t, i) {
        var n = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
            s = this,
            a = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
            o = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
        if (e && "addEventListener" in e && !l.empty(t) && l.function(i)) {
            var r = t.split(" "),
                u = o;
            c && (u = {
                passive: a,
                capture: o
            }), r.forEach(function(t) {
                s && s.eventListeners && n && s.eventListeners.push({
                    element: e,
                    type: t,
                    callback: i,
                    options: u
                }), e[n ? "addEventListener" : "removeEventListener"](t, i, u)
            })
        }
    }

    function d(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
            i = arguments[2],
            n = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
            s = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        u.call(this, e, t, i, !0, n, s)
    }

    function h(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
            i = arguments[2],
            n = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
            s = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        u.call(this, e, t, i, !1, n, s)
    }

    function p(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
            i = arguments[2],
            n = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
            s = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        u.call(this, e, t, function a() {
            h(e, t, a, n, s);
            for (var o = arguments.length, r = Array(o), l = 0; l < o; l++) r[l] = arguments[l];
            i.apply(this, r)
        }, !0, n, s)
    }

    function f(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
            i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
            n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
        if (l.element(e) && !l.empty(t)) {
            var s = new CustomEvent(t, {
                bubbles: i,
                detail: Object.assign({}, n, {
                    plyr: this
                })
            });
            e.dispatchEvent(s)
        }
    }
    var m = function(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        },
        g = function() {
            function e(e, t) {
                for (var i = 0; i < t.length; i++) {
                    var n = t[i];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }
            return function(t, i, n) {
                return i && e(t.prototype, i), n && e(t, n), t
            }
        }(),
        y = function(e, t, i) {
            return t in e ? Object.defineProperty(e, t, {
                value: i,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = i, e
        },
        v = function() {
            return function(e, t) {
                if (Array.isArray(e)) return e;
                if (Symbol.iterator in Object(e)) return function(e, t) {
                    var i = [],
                        n = !0,
                        s = !1,
                        a = void 0;
                    try {
                        for (var o, r = e[Symbol.iterator](); !(n = (o = r.next()).done) && (i.push(o.value), !t || i.length !== t); n = !0);
                    } catch (e) {
                        s = !0, a = e
                    } finally {
                        try {
                            !n && r.return && r.return()
                        } finally {
                            if (s) throw a
                        }
                    }
                    return i
                }(e, t);
                throw new TypeError("Invalid attempt to destructure non-iterable instance")
            }
        }();

    function b(e, t) {
        var i = e.length ? e : [e];
        Array.from(i).reverse().forEach(function(e, i) {
            var n = i > 0 ? t.cloneNode(!0) : t,
                s = e.parentNode,
                a = e.nextSibling;
            n.appendChild(e), a ? s.insertBefore(n, a) : s.appendChild(n)
        })
    }

    function k(e, t) {
        l.element(e) && !l.empty(t) && Object.entries(t).filter(function(e) {
            var t = v(e, 2)[1];
            return !l.nullOrUndefined(t)
        }).forEach(function(t) {
            var i = v(t, 2),
                n = i[0],
                s = i[1];
            return e.setAttribute(n, s)
        })
    }

    function w(e, t, i) {
        var n = document.createElement(e);
        return l.object(t) && k(n, t), l.string(i) && (n.innerText = i), n
    }

    function T(e, t, i, n) {
        l.element(t) && t.appendChild(w(e, i, n))
    }

    function A(e) {
        l.nodeList(e) || l.array(e) ? Array.from(e).forEach(A) : l.element(e) && l.element(e.parentNode) && e.parentNode.removeChild(e)
    }

    function E(e) {
        if (l.element(e))
            for (var t = e.childNodes.length; t > 0;) e.removeChild(e.lastChild), t -= 1
    }

    function C(e, t) {
        return l.element(t) && l.element(t.parentNode) && l.element(e) ? (t.parentNode.replaceChild(e, t), e) : null
    }

    function P(e, t) {
        if (!l.string(e) || l.empty(e)) return {};
        var i = {},
            n = t;
        return e.split(",").forEach(function(e) {
            var t = e.trim(),
                s = t.replace(".", ""),
                a = t.replace(/[[\]]/g, "").split("="),
                o = a[0],
                r = a.length > 1 ? a[1].replace(/["']/g, "") : "";
            switch (t.charAt(0)) {
                case ".":
                    l.object(n) && l.string(n.class) && (n.class += " " + s), i.class = s;
                    break;
                case "#":
                    i.id = t.replace("#", "");
                    break;
                case "[":
                    i[o] = r
            }
        }), i
    }

    function S(e, t) {
        if (l.element(e)) {
            var i = t;
            l.boolean(i) || (i = !e.hidden), i ? e.setAttribute("hidden", "") : e.removeAttribute("hidden")
        }
    }

    function M(e, t, i) {
        if (l.nodeList(e)) return Array.from(e).map(function(e) {
            return M(e, t, i)
        });
        if (l.element(e)) {
            var n = "toggle";
            return void 0 !== i && (n = i ? "add" : "remove"), e.classList[n](t), e.classList.contains(t)
        }
        return !1
    }

    function N(e, t) {
        return l.element(e) && e.classList.contains(t)
    }

    function L(e, t) {
        var i = {
            Element: Element
        };
        return (i.matches || i.webkitMatchesSelector || i.mozMatchesSelector || i.msMatchesSelector || function() {
            return Array.from(document.querySelectorAll(t)).includes(this)
        }).call(e, t)
    }

    function x(e) {
        return this.elements.container.querySelectorAll(e)
    }

    function _(e) {
        return this.elements.container.querySelector(e)
    }

    function I() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
            t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        l.element(e) && (e.focus(), t && M(e, this.config.classNames.tabFocus))
    }
    var O, j, q, R = (O = document.createElement("span"), j = {
        WebkitTransition: "webkitTransitionEnd",
        MozTransition: "transitionend",
        OTransition: "oTransitionEnd otransitionend",
        transition: "transitionend"
    }, q = Object.keys(j).find(function(e) {
        return void 0 !== O.style[e]
    }), !!l.string(q) && j[q]);

    function B(e) {
        setTimeout(function() {
            try {
                S(e, !0), e.offsetHeight, S(e, !1)
            } catch (e) {}
        }, 0)
    }
    var H, V = {
            isIE: !!document.documentMode,
            isWebkit: "WebkitAppearance" in document.documentElement.style && !/Edge/.test(navigator.userAgent),
            isIPhone: /(iPhone|iPod)/gi.test(navigator.platform),
            isIos: /(iPad|iPhone|iPod)/gi.test(navigator.platform)
        },
        D = {
            "audio/ogg": "vorbis",
            "audio/wav": "1",
            "video/webm": "vp8, vorbis",
            "video/mp4": "avc1.42E01E, mp4a.40.2",
            "video/ogg": "theora"
        },
        F = {
            audio: "canPlayType" in document.createElement("audio"),
            video: "canPlayType" in document.createElement("video"),
            check: function(e, t, i) {
                var n = V.isIPhone && i && F.playsinline,
                    s = F[e] || "html5" !== t;
                return {
                    api: s,
                    ui: s && F.rangeInput && ("video" !== e || !V.isIPhone || n)
                }
            },
            pip: !V.isIPhone && l.function(w("video").webkitSetPresentationMode),
            airplay: l.function(window.WebKitPlaybackTargetAvailabilityEvent),
            playsinline: "playsInline" in document.createElement("video"),
            mime: function(e) {
                var t = e.split("/"),
                    i = v(t, 1)[0];
                if (!this.isHTML5 || i !== this.type) return !1;
                var n = void 0;
                e && e.includes("codecs=") ? n = e : "audio/mpeg" === e ? n = "audio/mpeg;" : e in D && (n = e + '; codecs="' + D[e] + '"');
                try {
                    return Boolean(n && this.media.canPlayType(n).replace(/no/, ""))
                } catch (e) {
                    return !1
                }
            },
            textTracks: "textTracks" in document.createElement("video"),
            rangeInput: (H = document.createElement("input"), H.type = "range", "range" === H.type),
            touch: "ontouchstart" in document.documentElement,
            transitions: !1 !== R,
            reducedMotion: "matchMedia" in window && window.matchMedia("(prefers-reduced-motion)").matches
        },
        U = {
            getSources: function() {
                var e = this;
                return this.isHTML5 ? Array.from(this.media.querySelectorAll("source")).filter(function(t) {
                    return F.mime.call(e, t.getAttribute("type"))
                }) : []
            },
            getQualityOptions: function() {
                return U.getSources.call(this).map(function(e) {
                    return Number(e.getAttribute("size"))
                }).filter(Boolean)
            },
            extend: function() {
                if (this.isHTML5) {
                    var e = this;
                    Object.defineProperty(e.media, "quality", {
                        get: function() {
                            var t = U.getSources.call(e).find(function(t) {
                                return t.getAttribute("src") === e.source
                            });
                            return t && Number(t.getAttribute("size"))
                        },
                        set: function(t) {
                            var i = U.getSources.call(e).find(function(e) {
                                return Number(e.getAttribute("size")) === t
                            });
                            if (i) {
                                var n = e.media,
                                    s = n.currentTime,
                                    a = n.paused,
                                    o = n.preload,
                                    r = n.readyState;
                                e.media.src = i.getAttribute("src"), ("none" !== o || r) && (e.once("loadedmetadata", function() {
                                    e.currentTime = s, a || e.play()
                                }), e.media.load()), f.call(e, e.media, "qualitychange", !1, {
                                    quality: t
                                }), e.storage.set({
                                    quality: t
                                })
                            }
                        }
                    })
                }
            },
            cancelRequests: function() {
                this.isHTML5 && (A(U.getSources.call(this)), this.media.setAttribute("src", this.config.blankVideo), this.media.load(), this.debug.log("Cancelled network requests"))
            }
        };

    function z(e) {
        return l.array(e) ? e.filter(function(t, i) {
            return e.indexOf(t) === i
        }) : e
    }

    function W(e, t) {
        return t.split(".").reduce(function(e, t) {
            return e && e[t]
        }, e)
    }

    function K() {
        for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length, i = Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) i[n - 1] = arguments[n];
        if (!i.length) return e;
        var s = i.shift();
        return l.object(s) ? (Object.keys(s).forEach(function(t) {
            l.object(s[t]) ? (Object.keys(e).includes(t) || Object.assign(e, y({}, t, {})), K(e[t], s[t])) : Object.assign(e, y({}, t, s[t]))
        }), K.apply(void 0, [e].concat(i))) : e
    }

    function Y(e) {
        for (var t = arguments.length, i = Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) i[n - 1] = arguments[n];
        return l.empty(e) ? e : e.toString().replace(/{(\d+)}/g, function(e, t) {
            return i[t].toString()
        })
    }

    function J() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
            t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
            i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
        return e.replace(new RegExp(t.toString().replace(/([.*+?^=!:${}()|[\]\/\\])/g, "\\$1"), "g"), i.toString())
    }

    function Q() {
        return (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "").toString().replace(/\w\S*/g, function(e) {
            return e.charAt(0).toUpperCase() + e.substr(1).toLowerCase()
        })
    }

    function $() {
        var e = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "").toString();
        return (e = function() {
            var e = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "").toString();
            return e = J(e, "-", " "), e = J(e, "_", " "), J(e = Q(e), " ", "")
        }(e)).charAt(0).toLowerCase() + e.slice(1)
    }

    function G(e) {
        var t = document.createElement("div");
        return t.appendChild(e), t.innerHTML
    }
    var X = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            if (l.empty(e) || l.empty(t)) return "";
            var i = W(t.i18n, e);
            if (l.empty(i)) return "";
            var n = {
                "{seektime}": t.seekTime,
                "{title}": t.title
            };
            return Object.entries(n).forEach(function(e) {
                var t = v(e, 2),
                    n = t[0],
                    s = t[1];
                i = J(i, n, s)
            }), i
        },
        Z = function() {
            function e(t) {
                m(this, e), this.enabled = t.config.storage.enabled, this.key = t.config.storage.key
            }
            return g(e, [{
                key: "get",
                value: function(t) {
                    if (!e.supported || !this.enabled) return null;
                    var i = window.localStorage.getItem(this.key);
                    if (l.empty(i)) return null;
                    var n = JSON.parse(i);
                    return l.string(t) && t.length ? n[t] : n
                }
            }, {
                key: "set",
                value: function(t) {
                    if (e.supported && this.enabled && l.object(t)) {
                        var i = this.get();
                        l.empty(i) && (i = {}), K(i, t), window.localStorage.setItem(this.key, JSON.stringify(i))
                    }
                }
            }], [{
                key: "supported",
                get: function() {
                    try {
                        if (!("localStorage" in window)) return !1;
                        return window.localStorage.setItem("___test", "___test"), window.localStorage.removeItem("___test"), !0
                    } catch (e) {
                        return !1
                    }
                }
            }]), e
        }();

    function ee(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "text";
        return new Promise(function(i, n) {
            try {
                var s = new XMLHttpRequest;
                if (!("withCredentials" in s)) return;
                s.addEventListener("load", function() {
                    if ("text" === t) try {
                        i(JSON.parse(s.responseText))
                    } catch (e) {
                        i(s.responseText)
                    } else i(s.response)
                }), s.addEventListener("error", function() {
                    throw new Error(s.status)
                }), s.open("GET", e, !0), s.responseType = t, s.send()
            } catch (e) {
                n(e)
            }
        })
    }

    function te(e, t) {
        if (l.string(e)) {
            var i = l.string(t),
                n = function() {
                    return null !== document.getElementById(t)
                },
                s = function(e, t) {
                    e.innerHTML = t, i && n() || document.body.insertAdjacentElement("afterbegin", e)
                };
            if (!i || !n()) {
                var a = Z.supported,
                    o = document.createElement("div");
                if (o.setAttribute("hidden", ""), i && o.setAttribute("id", t), a) {
                    var r = window.localStorage.getItem("cache-" + t);
                    if (null !== r) {
                        var c = JSON.parse(r);
                        s(o, c.content)
                    }
                }
                ee(e).then(function(e) {
                    l.empty(e) || (a && window.localStorage.setItem("cache-" + t, JSON.stringify({
                        content: e
                    })), s(o, e))
                }).catch(function() {})
            }
        }
    }
    var ie = function(e) {
            return parseInt(e / 60 / 60 % 60, 10)
        },
        ne = function(e) {
            return parseInt(e / 60 % 60, 10)
        },
        se = function(e) {
            return parseInt(e % 60, 10)
        };

    function ae() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
            t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        if (!l.number(e)) return ae(null, t, i);
        var n = function(e) {
                return ("0" + e).slice(-2)
            },
            s = ie(e),
            a = ne(e),
            o = se(e);
        return t || s > 0 ? s += ":" : s = "", (i && e > 0 ? "-" : "") + s + n(a) + ":" + n(o)
    }
    var oe = {
        getIconUrl: function() {
            var e = new URL(this.config.iconUrl, window.location).host !== window.location.host || V.isIE && !window.svg4everybody;
            return {
                url: this.config.iconUrl,
                cors: e
            }
        },
        findElements: function() {
            try {
                return this.elements.controls = _.call(this, this.config.selectors.controls.wrapper), this.elements.buttons = {
                    play: x.call(this, this.config.selectors.buttons.play),
                    pause: _.call(this, this.config.selectors.buttons.pause),
                    restart: _.call(this, this.config.selectors.buttons.restart),
                    rewind: _.call(this, this.config.selectors.buttons.rewind),
                    fastForward: _.call(this, this.config.selectors.buttons.fastForward),
                    mute: _.call(this, this.config.selectors.buttons.mute),
                    pip: _.call(this, this.config.selectors.buttons.pip),
                    airplay: _.call(this, this.config.selectors.buttons.airplay),
                    settings: _.call(this, this.config.selectors.buttons.settings),
                    captions: _.call(this, this.config.selectors.buttons.captions),
                    fullscreen: _.call(this, this.config.selectors.buttons.fullscreen)
                }, this.elements.progress = _.call(this, this.config.selectors.progress), this.elements.inputs = {
                    seek: _.call(this, this.config.selectors.inputs.seek),
                    volume: _.call(this, this.config.selectors.inputs.volume)
                }, this.elements.display = {
                    buffer: _.call(this, this.config.selectors.display.buffer),
                    currentTime: _.call(this, this.config.selectors.display.currentTime),
                    duration: _.call(this, this.config.selectors.display.duration)
                }, l.element(this.elements.progress) && (this.elements.display.seekTooltip = this.elements.progress.querySelector("." + this.config.classNames.tooltip)), !0
            } catch (e) {
                return this.debug.warn("It looks like there is a problem with your custom controls HTML", e), this.toggleNativeControls(!0), !1
            }
        },
        createIcon: function(e, t) {
            var i = oe.getIconUrl.call(this),
                n = (i.cors ? "" : i.url) + "#" + this.config.iconPrefix,
                s = document.createElementNS("http://www.w3.org/2000/svg", "svg");
            k(s, K(t, {
                role: "presentation",
                focusable: "false"
            }));
            var a = document.createElementNS("http://www.w3.org/2000/svg", "use"),
                o = n + "-" + e;
            return "href" in a ? a.setAttributeNS("http://www.w3.org/1999/xlink", "href", o) : a.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", o), s.appendChild(a), s
        },
        createLabel: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                i = {
                    pip: "PIP",
                    airplay: "AirPlay"
                }[e] || X(e, this.config);
            return w("span", Object.assign({}, t, {
                class: [t.class, this.config.classNames.hidden].filter(Boolean).join(" ")
            }), i)
        },
        createBadge: function(e) {
            if (l.empty(e)) return null;
            var t = w("span", {
                class: this.config.classNames.menu.value
            });
            return t.appendChild(w("span", {
                class: this.config.classNames.menu.badge
            }, e)), t
        },
        createButton: function(e, t) {
            var i = w("button"),
                n = Object.assign({}, t),
                s = $(e),
                a = !1,
                o = void 0,
                r = void 0,
                c = void 0,
                u = void 0;
            switch ("type" in n || (n.type = "button"), "class" in n ? n.class.includes(this.config.classNames.control) || (n.class += " " + this.config.classNames.control) : n.class = this.config.classNames.control, e) {
                case "play":
                    a = !0, o = "play", c = "pause", r = "play", u = "pause";
                    break;
                case "mute":
                    a = !0, o = "mute", c = "unmute", r = "volume", u = "muted";
                    break;
                case "captions":
                    a = !0, o = "enableCaptions", c = "disableCaptions", r = "captions-off", u = "captions-on";
                    break;
                case "fullscreen":
                    a = !0, o = "enterFullscreen", c = "exitFullscreen", r = "enter-fullscreen", u = "exit-fullscreen";
                    break;
                case "play-large":
                    n.class += " " + this.config.classNames.control + "--overlaid", s = "play", o = "play", r = "play";
                    break;
                default:
                    o = s, r = e
            }
            return a ? (i.appendChild(oe.createIcon.call(this, u, {
                class: "icon--pressed"
            })), i.appendChild(oe.createIcon.call(this, r, {
                class: "icon--not-pressed"
            })), i.appendChild(oe.createLabel.call(this, c, {
                class: "label--pressed"
            })), i.appendChild(oe.createLabel.call(this, o, {
                class: "label--not-pressed"
            }))) : (i.appendChild(oe.createIcon.call(this, r)), i.appendChild(oe.createLabel.call(this, o))), K(n, P(this.config.selectors.buttons[s], n)), k(i, n), "play" === s ? (l.array(this.elements.buttons[s]) || (this.elements.buttons[s] = []), this.elements.buttons[s].push(i)) : this.elements.buttons[s] = i, i
        },
        createRange: function(e, t) {
            var i = w("input", K(P(this.config.selectors.inputs[e]), {
                type: "range",
                min: 0,
                max: 100,
                step: .01,
                value: 0,
                autocomplete: "off",
                role: "slider",
                "aria-label": X(e, this.config),
                "aria-valuemin": 0,
                "aria-valuemax": 100,
                "aria-valuenow": 0
            }, t));
            return this.elements.inputs[e] = i, oe.updateRangeFill.call(this, i), i
        },
        createProgress: function(e, t) {
            var i = w("progress", K(P(this.config.selectors.display[e]), {
                min: 0,
                max: 100,
                value: 0,
                role: "presentation",
                "aria-hidden": !0
            }, t));
            if ("volume" !== e) {
                i.appendChild(w("span", null, "0"));
                var n = {
                        played: "played",
                        buffer: "buffered"
                    }[e],
                    s = n ? X(n, this.config) : "";
                i.innerText = "% " + s.toLowerCase()
            }
            return this.elements.display[e] = i, i
        },
        createTime: function(e) {
            var t = P(this.config.selectors.display[e]),
                i = w("div", K(t, {
                    class: (this.config.classNames.display.time + " " + (t.class ? t.class : "")).trim(),
                    "aria-label": X(e, this.config)
                }), "00:00");
            return this.elements.display[e] = i, i
        },
        bindMenuItemShortcuts: function(e, t) {
            var i = this;
            d(e, "keydown keyup", function(n) {
                if ([32, 38, 39, 40].includes(n.which) && (n.preventDefault(), n.stopPropagation(), "keydown" !== n.type)) {
                    var s = L(e, '[role="menuitemradio"]');
                    if (!s && [32, 39].includes(n.which)) oe.showMenuPanel.call(i, t, !0);
                    else {
                        var a = void 0;
                        32 !== n.which && (40 === n.which || s && 39 === n.which ? (a = e.nextElementSibling, l.element(a) || (a = e.parentNode.firstElementChild)) : (a = e.previousElementSibling, l.element(a) || (a = e.parentNode.lastElementChild)), I.call(i, a, !0))
                    }
                }
            }, !1), d(e, "keyup", function(e) {
                13 === e.which && oe.focusFirstMenuItem.call(i, null, !0)
            })
        },
        createMenuItem: function(e) {
            var t = this,
                i = e.value,
                n = e.list,
                s = e.type,
                a = e.title,
                o = e.badge,
                r = void 0 === o ? null : o,
                c = e.checked,
                u = void 0 !== c && c,
                d = P(this.config.selectors.inputs[s]),
                h = w("button", K(d, {
                    type: "button",
                    role: "menuitemradio",
                    class: (this.config.classNames.control + " " + (d.class ? d.class : "")).trim(),
                    "aria-checked": u,
                    value: i
                })),
                p = w("span");
            p.innerHTML = a, l.element(r) && p.appendChild(r), h.appendChild(p), Object.defineProperty(h, "checked", {
                enumerable: !0,
                get: function() {
                    return "true" === h.getAttribute("aria-checked")
                },
                set: function(e) {
                    e && Array.from(h.parentNode.children).filter(function(e) {
                        return L(e, '[role="menuitemradio"]')
                    }).forEach(function(e) {
                        return e.setAttribute("aria-checked", "false")
                    }), h.setAttribute("aria-checked", e ? "true" : "false")
                }
            }), this.listeners.bind(h, "click keyup", function(e) {
                if (!l.keyboardEvent(e) || 32 === e.which) {
                    switch (e.preventDefault(), e.stopPropagation(), h.checked = !0, s) {
                        case "language":
                            t.currentTrack = Number(i);
                            break;
                        case "quality":
                            t.quality = i;
                            break;
                        case "speed":
                            t.speed = parseFloat(i)
                    }
                    oe.showMenuPanel.call(t, "home", l.keyboardEvent(e))
                }
            }, s, !1), oe.bindMenuItemShortcuts.call(this, h, s), n.appendChild(h)
        },
        formatTime: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            return l.number(e) ? ae(e, ie(this.duration) > 0, t) : e
        },
        updateTimeDisplay: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
            l.element(e) && l.number(t) && (e.innerText = oe.formatTime(t, i))
        },
        updateVolume: function() {
            this.supported.ui && (l.element(this.elements.inputs.volume) && oe.setRange.call(this, this.elements.inputs.volume, this.muted ? 0 : this.volume), l.element(this.elements.buttons.mute) && (this.elements.buttons.mute.pressed = this.muted || 0 === this.volume))
        },
        setRange: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
            l.element(e) && (e.value = t, oe.updateRangeFill.call(this, e))
        },
        updateProgress: function(e) {
            var t = this;
            if (this.supported.ui && l.event(e)) {
                var i, n, s = 0;
                if (e) switch (e.type) {
                    case "timeupdate":
                    case "seeking":
                    case "seeked":
                        i = this.currentTime, n = this.duration, s = 0 === i || 0 === n || Number.isNaN(i) || Number.isNaN(n) ? 0 : (i / n * 100).toFixed(2), "timeupdate" === e.type && oe.setRange.call(this, this.elements.inputs.seek, s);
                        break;
                    case "playing":
                    case "progress":
                        ! function(e, i) {
                            var n = l.number(i) ? i : 0,
                                s = l.element(e) ? e : t.elements.display.buffer;
                            if (l.element(s)) {
                                s.value = n;
                                var a = s.getElementsByTagName("span")[0];
                                l.element(a) && (a.childNodes[0].nodeValue = n)
                            }
                        }(this.elements.display.buffer, 100 * this.buffered)
                }
            }
        },
        updateRangeFill: function(e) {
            var t = l.event(e) ? e.target : e;
            if (l.element(t) && "range" === t.getAttribute("type")) {
                if (L(t, this.config.selectors.inputs.seek)) {
                    t.setAttribute("aria-valuenow", this.currentTime);
                    var i = oe.formatTime(this.currentTime),
                        n = oe.formatTime(this.duration),
                        s = X("seekLabel", this.config);
                    t.setAttribute("aria-valuetext", s.replace("{currentTime}", i).replace("{duration}", n))
                } else if (L(t, this.config.selectors.inputs.volume)) {
                    var a = 100 * t.value;
                    t.setAttribute("aria-valuenow", a), t.setAttribute("aria-valuetext", a.toFixed(1) + "%")
                } else t.setAttribute("aria-valuenow", t.value);
                V.isWebkit && t.style.setProperty("--value", t.value / t.max * 100 + "%")
            }
        },
        updateSeekTooltip: function(e) {
            var t = this;
            if (this.config.tooltips.seek && l.element(this.elements.inputs.seek) && l.element(this.elements.display.seekTooltip) && 0 !== this.duration) {
                var i = 0,
                    n = this.elements.progress.getBoundingClientRect(),
                    s = this.config.classNames.tooltip + "--visible",
                    a = function(e) {
                        M(t.elements.display.seekTooltip, s, e)
                    };
                if (this.touch) a(!1);
                else {
                    if (l.event(e)) i = 100 / n.width * (e.pageX - n.left);
                    else {
                        if (!N(this.elements.display.seekTooltip, s)) return;
                        i = parseFloat(this.elements.display.seekTooltip.style.left, 10)
                    }
                    i < 0 ? i = 0 : i > 100 && (i = 100), oe.updateTimeDisplay.call(this, this.elements.display.seekTooltip, this.duration / 100 * i), this.elements.display.seekTooltip.style.left = i + "%", l.event(e) && ["mouseenter", "mouseleave"].includes(e.type) && a("mouseenter" === e.type)
                }
            }
        },
        timeUpdate: function(e) {
            var t = !l.element(this.elements.display.duration) && this.config.invertTime;
            oe.updateTimeDisplay.call(this, this.elements.display.currentTime, t ? this.duration - this.currentTime : this.currentTime, t), e && "timeupdate" === e.type && this.media.seeking || oe.updateProgress.call(this, e)
        },
        durationUpdate: function() {
            if (this.supported.ui && (this.config.invertTime || !this.currentTime)) {
                if (this.duration >= Math.pow(2, 32)) return S(this.elements.display.currentTime, !0), void S(this.elements.progress, !0);
                l.element(this.elements.inputs.seek) && this.elements.inputs.seek.setAttribute("aria-valuemax", this.duration);
                var e = l.element(this.elements.display.duration);
                !e && this.config.displayDuration && this.paused && oe.updateTimeDisplay.call(this, this.elements.display.currentTime, this.duration), e && oe.updateTimeDisplay.call(this, this.elements.display.duration, this.duration), oe.updateSeekTooltip.call(this)
            }
        },
        toggleMenuButton: function(e, t) {
            S(this.elements.settings.buttons[e], !t)
        },
        updateSetting: function(e, t, i) {
            var n = this.elements.settings.panels[e],
                s = null,
                a = t;
            if ("captions" === e) s = this.currentTrack;
            else {
                if (s = l.empty(i) ? this[e] : i, l.empty(s) && (s = this.config[e].default), !l.empty(this.options[e]) && !this.options[e].includes(s)) return void this.debug.warn("Unsupported value of '" + s + "' for " + e);
                if (!this.config[e].options.includes(s)) return void this.debug.warn("Disabled value of '" + s + "' for " + e)
            }
            if (l.element(a) || (a = n && n.querySelector('[role="menu"]')), l.element(a)) {
                this.elements.settings.buttons[e].querySelector("." + this.config.classNames.menu.value).innerHTML = oe.getLabel.call(this, e, s);
                var o = a && a.querySelector('[value="' + s + '"]');
                l.element(o) && (o.checked = !0)
            }
        },
        getLabel: function(e, t) {
            switch (e) {
                case "speed":
                    return 1 === t ? X("normal", this.config) : t + "&times;";
                case "quality":
                    if (l.number(t)) {
                        var i = X("qualityLabel." + t, this.config);
                        return i.length ? i : t + "p"
                    }
                    return Q(t);
                case "captions":
                    return ce.getLabel.call(this);
                default:
                    return null
            }
        },
        setQualityMenu: function(e) {
            var t = this;
            if (l.element(this.elements.settings.panels.quality)) {
                var i = this.elements.settings.panels.quality.querySelector('[role="menu"]');
                l.array(e) && (this.options.quality = z(e).filter(function(e) {
                    return t.config.quality.options.includes(e)
                }));
                var n = !l.empty(this.options.quality) && this.options.quality.length > 1;
                if (oe.toggleMenuButton.call(this, "quality", n), E(i), oe.checkMenu.call(this), n) {
                    this.options.quality.sort(function(e, i) {
                        var n = t.config.quality.options;
                        return n.indexOf(e) > n.indexOf(i) ? 1 : -1
                    }).forEach(function(e) {
                        oe.createMenuItem.call(t, {
                            value: e,
                            list: i,
                            type: "quality",
                            title: oe.getLabel.call(t, "quality", e),
                            badge: function(e) {
                                var i = X("qualityBadge." + e, t.config);
                                return i.length ? oe.createBadge.call(t, i) : null
                            }(e)
                        })
                    }), oe.updateSetting.call(this, "quality", i)
                }
            }
        },
        setCaptionsMenu: function() {
            var e = this;
            if (l.element(this.elements.settings.panels.captions)) {
                var t = this.elements.settings.panels.captions.querySelector('[role="menu"]'),
                    i = ce.getTracks.call(this),
                    n = Boolean(i.length);
                if (oe.toggleMenuButton.call(this, "captions", n), E(t), oe.checkMenu.call(this), n) {
                    var s = i.map(function(i, n) {
                        return {
                            value: n,
                            checked: e.captions.toggled && e.currentTrack === n,
                            title: ce.getLabel.call(e, i),
                            badge: i.language && oe.createBadge.call(e, i.language.toUpperCase()),
                            list: t,
                            type: "language"
                        }
                    });
                    s.unshift({
                        value: -1,
                        checked: !this.captions.toggled,
                        title: X("disabled", this.config),
                        list: t,
                        type: "language"
                    }), s.forEach(oe.createMenuItem.bind(this)), oe.updateSetting.call(this, "captions", t)
                }
            }
        },
        setSpeedMenu: function(e) {
            var t = this;
            if (l.element(this.elements.settings.panels.speed)) {
                var i = this.elements.settings.panels.speed.querySelector('[role="menu"]');
                l.array(e) ? this.options.speed = e : (this.isHTML5 || this.isVimeo) && (this.options.speed = [.5, .75, 1, 1.25, 1.5, 1.75, 2]), this.options.speed = this.options.speed.filter(function(e) {
                    return t.config.speed.options.includes(e)
                });
                var n = !l.empty(this.options.speed) && this.options.speed.length > 1;
                oe.toggleMenuButton.call(this, "speed", n), E(i), oe.checkMenu.call(this), n && (this.options.speed.forEach(function(e) {
                    oe.createMenuItem.call(t, {
                        value: e,
                        list: i,
                        type: "speed",
                        title: oe.getLabel.call(t, "speed", e)
                    })
                }), oe.updateSetting.call(this, "speed", i))
            }
        },
        checkMenu: function() {
            var e = this.elements.settings.buttons,
                t = !l.empty(e) && Object.values(e).some(function(e) {
                    return !e.hidden
                });
            S(this.elements.settings.menu, !t)
        },
        focusFirstMenuItem: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            if (!this.elements.settings.popup.hidden) {
                var i = e;
                l.element(i) || (i = Object.values(this.elements.settings.panels).find(function(e) {
                    return !e.hidden
                }));
                var n = i.querySelector('[role^="menuitem"]');
                I.call(this, n, t)
            }
        },
        toggleMenu: function(e) {
            var t = this.elements.settings.popup,
                i = this.elements.buttons.settings;
            if (l.element(t) && l.element(i)) {
                var n = t.hidden,
                    s = n;
                if (l.boolean(e)) s = e;
                else if (l.keyboardEvent(e) && 27 === e.which) s = !1;
                else if (l.event(e)) {
                    var a = t.contains(e.target);
                    if (a || !a && e.target !== i && s) return
                }
                i.setAttribute("aria-expanded", s), S(t, !s), M(this.elements.container, this.config.classNames.menu.open, s), s && l.keyboardEvent(e) ? oe.focusFirstMenuItem.call(this, null, !0) : s || n || I.call(this, i, l.keyboardEvent(e))
            }
        },
        getMenuSize: function(e) {
            var t = e.cloneNode(!0);
            t.style.position = "absolute", t.style.opacity = 0, t.removeAttribute("hidden"), e.parentNode.appendChild(t);
            var i = t.scrollWidth,
                n = t.scrollHeight;
            return A(t), {
                width: i,
                height: n
            }
        },
        showMenuPanel: function() {
            var e = this,
                t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                n = document.getElementById("plyr-settings-" + this.id + "-" + t);
            if (l.element(n)) {
                var s = n.parentNode,
                    a = Array.from(s.children).find(function(e) {
                        return !e.hidden
                    });
                if (F.transitions && !F.reducedMotion) {
                    s.style.width = a.scrollWidth + "px", s.style.height = a.scrollHeight + "px";
                    var o = oe.getMenuSize.call(this, n);
                    d.call(this, s, R, function t(i) {
                        i.target === s && ["width", "height"].includes(i.propertyName) && (s.style.width = "", s.style.height = "", h.call(e, s, R, t))
                    }), s.style.width = o.width + "px", s.style.height = o.height + "px"
                }
                S(a, !0), S(n, !1), oe.focusFirstMenuItem.call(this, n, i)
            }
        },
        create: function(e) {
            var t = this,
                i = w("div", P(this.config.selectors.controls.wrapper));
            if (this.config.controls.includes("restart") && i.appendChild(oe.createButton.call(this, "restart")), this.config.controls.includes("rewind") && i.appendChild(oe.createButton.call(this, "rewind")), this.config.controls.includes("play") && i.appendChild(oe.createButton.call(this, "play")), this.config.controls.includes("fast-forward") && i.appendChild(oe.createButton.call(this, "fast-forward")), this.config.controls.includes("progress")) {
                var n = w("div", P(this.config.selectors.progress));
                if (n.appendChild(oe.createRange.call(this, "seek", {
                        id: "plyr-seek-" + e.id
                    })), n.appendChild(oe.createProgress.call(this, "buffer")), this.config.tooltips.seek) {
                    var s = w("span", {
                        class: this.config.classNames.tooltip
                    }, "00:00");
                    n.appendChild(s), this.elements.display.seekTooltip = s
                }
                this.elements.progress = n, i.appendChild(this.elements.progress)
            }
            if (this.config.controls.includes("current-time") && i.appendChild(oe.createTime.call(this, "currentTime")), this.config.controls.includes("duration") && i.appendChild(oe.createTime.call(this, "duration")), this.config.controls.includes("mute") || this.config.controls.includes("volume")) {
                var a = w("div", {
                    class: "plyr__volume"
                });
                if (this.config.controls.includes("mute") && a.appendChild(oe.createButton.call(this, "mute")), this.config.controls.includes("volume")) {
                    var o = {
                        max: 1,
                        step: .05,
                        value: this.config.volume
                    };
                    a.appendChild(oe.createRange.call(this, "volume", K(o, {
                        id: "plyr-volume-" + e.id
                    }))), this.elements.volume = a
                }
                i.appendChild(a)
            }
            if (this.config.controls.includes("captions") && i.appendChild(oe.createButton.call(this, "captions")), this.config.controls.includes("settings") && !l.empty(this.config.settings)) {
                var r = w("div", {
                    class: "plyr__menu",
                    hidden: ""
                });
                r.appendChild(oe.createButton.call(this, "settings", {
                    "aria-haspopup": !0,
                    "aria-controls": "plyr-settings-" + e.id,
                    "aria-expanded": !1
                }));
                var c = w("div", {
                        class: "plyr__menu__container",
                        id: "plyr-settings-" + e.id,
                        hidden: ""
                    }),
                    u = w("div"),
                    h = w("div", {
                        id: "plyr-settings-" + e.id + "-home"
                    }),
                    p = w("div", {
                        role: "menu"
                    });
                h.appendChild(p), u.appendChild(h), this.elements.settings.panels.home = h, this.config.settings.forEach(function(i) {
                    var n = w("button", K(P(t.config.selectors.buttons.settings), {
                        type: "button",
                        class: t.config.classNames.control + " " + t.config.classNames.control + "--forward",
                        role: "menuitem",
                        "aria-haspopup": !0,
                        hidden: ""
                    }));
                    oe.bindMenuItemShortcuts.call(t, n, i), d(n, "click", function() {
                        oe.showMenuPanel.call(t, i, !1)
                    });
                    var s = w("span", null, X(i, t.config)),
                        a = w("span", {
                            class: t.config.classNames.menu.value
                        });
                    a.innerHTML = e[i], s.appendChild(a), n.appendChild(s), p.appendChild(n);
                    var o = w("div", {
                            id: "plyr-settings-" + e.id + "-" + i,
                            hidden: ""
                        }),
                        r = w("button", {
                            type: "button",
                            class: t.config.classNames.control + " " + t.config.classNames.control + "--back"
                        });
                    r.appendChild(w("span", {
                        "aria-hidden": !0
                    }, X(i, t.config))), r.appendChild(w("span", {
                        class: t.config.classNames.hidden
                    }, X("menuBack", t.config))), d(o, "keydown", function(e) {
                        37 === e.which && (e.preventDefault(), e.stopPropagation(), oe.showMenuPanel.call(t, "home", !0))
                    }, !1), d(r, "click", function() {
                        oe.showMenuPanel.call(t, "home", !1)
                    }), o.appendChild(r), o.appendChild(w("div", {
                        role: "menu"
                    })), u.appendChild(o), t.elements.settings.buttons[i] = n, t.elements.settings.panels[i] = o
                }), c.appendChild(u), r.appendChild(c), i.appendChild(r), this.elements.settings.popup = c, this.elements.settings.menu = r
            }
            return this.config.controls.includes("pip") && F.pip && i.appendChild(oe.createButton.call(this, "pip")), this.config.controls.includes("airplay") && F.airplay && i.appendChild(oe.createButton.call(this, "airplay")), this.config.controls.includes("fullscreen") && i.appendChild(oe.createButton.call(this, "fullscreen")), this.config.controls.includes("play-large") && this.elements.container.appendChild(oe.createButton.call(this, "play-large")), this.elements.controls = i, this.isHTML5 && oe.setQualityMenu.call(this, U.getQualityOptions.call(this)), oe.setSpeedMenu.call(this), i
        },
        inject: function() {
            var e = this;
            if (this.config.loadSprite) {
                var t = oe.getIconUrl.call(this);
                t.cors && te(t.url, "sprite-plyr")
            }
            this.id = Math.floor(1e4 * Math.random());
            var i = null;
            this.elements.controls = null;
            var n = {
                    id: this.id,
                    seektime: this.config.seekTime,
                    title: this.config.title
                },
                s = !0;
            l.function(this.config.controls) && (this.config.controls = this.config.controls.call(this.props)), this.config.controls || (this.config.controls = []), l.element(this.config.controls) || l.string(this.config.controls) ? i = this.config.controls : (i = oe.create.call(this, {
                id: this.id,
                seektime: this.config.seekTime,
                speed: this.speed,
                quality: this.quality,
                captions: ce.getLabel.call(this)
            }), s = !1);
            var a = function(e) {
                var t = e;
                return Object.entries(n).forEach(function(e) {
                    var i = v(e, 2),
                        n = i[0],
                        s = i[1];
                    t = J(t, "{" + n + "}", s)
                }), t
            };
            s && (l.string(this.config.controls) ? i = a(i) : l.element(i) && (i.innerHTML = a(i.innerHTML)));
            var o = void 0;
            if (l.string(this.config.selectors.controls.container) && (o = document.querySelector(this.config.selectors.controls.container)), l.element(o) || (o = this.elements.container), o[l.element(i) ? "insertAdjacentElement" : "insertAdjacentHTML"]("afterbegin", i), l.element(this.elements.controls) || oe.findElements.call(this), !l.empty(this.elements.buttons)) {
                var r = function(t) {
                    var i = e.config.classNames.controlPressed;
                    Object.defineProperty(t, "pressed", {
                        enumerable: !0,
                        get: function() {
                            return N(t, i)
                        },
                        set: function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                            M(t, i, e)
                        }
                    })
                };
                Object.values(this.elements.buttons).filter(Boolean).forEach(function(e) {
                    l.array(e) || l.nodeList(e) ? Array.from(e).filter(Boolean).forEach(r) : r(e)
                })
            }
            if (window.navigator.userAgent.includes("Edge") && B(o), this.config.tooltips.controls) {
                var c = this.config,
                    u = c.classNames,
                    d = c.selectors,
                    h = d.controls.wrapper + " " + d.labels + " ." + u.hidden,
                    p = x.call(this, h);
                Array.from(p).forEach(function(t) {
                    M(t, e.config.classNames.hidden, !1), M(t, e.config.classNames.tooltip, !0)
                })
            }
        }
    };

    function re(e) {
        var t = e;
        if (!(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1]) {
            var i = document.createElement("a");
            i.href = t, t = i.href
        }
        try {
            return new URL(t)
        } catch (e) {
            return null
        }
    }

    function le(e) {
        var t = new URLSearchParams;
        return l.object(e) && Object.entries(e).forEach(function(e) {
            var i = v(e, 2),
                n = i[0],
                s = i[1];
            t.set(n, s)
        }), t
    }
    var ce = {
            setup: function() {
                if (this.supported.ui)
                    if (!this.isVideo || this.isYouTube || this.isHTML5 && !F.textTracks) l.array(this.config.controls) && this.config.controls.includes("settings") && this.config.settings.includes("captions") && oe.setCaptionsMenu.call(this);
                    else {
                        var e, t;
                        if (l.element(this.elements.captions) || (this.elements.captions = w("div", P(this.config.selectors.captions)), e = this.elements.captions, t = this.elements.wrapper, l.element(e) && l.element(t) && t.parentNode.insertBefore(e, t.nextSibling)), V.isIE && window.URL) {
                            var i = this.media.querySelectorAll("track");
                            Array.from(i).forEach(function(e) {
                                var t = e.getAttribute("src"),
                                    i = re(t);
                                null !== i && i.hostname !== window.location.href.hostname && ["http:", "https:"].includes(i.protocol) && ee(t, "blob").then(function(t) {
                                    e.setAttribute("src", window.URL.createObjectURL(t))
                                }).catch(function() {
                                    A(e)
                                })
                            })
                        }
                        var n = z((navigator.languages || [navigator.language || navigator.userLanguage || "en"]).map(function(e) {
                                return e.split("-")[0]
                            })),
                            s = (this.storage.get("language") || this.config.captions.language || "auto").toLowerCase();
                        if ("auto" === s) s = v(n, 1)[0];
                        var a = this.storage.get("captions");
                        if (l.boolean(a) || (a = this.config.captions.active), Object.assign(this.captions, {
                                toggled: !1,
                                active: a,
                                language: s,
                                languages: n
                            }), this.isHTML5) {
                            var o = this.config.captions.update ? "addtrack removetrack" : "removetrack";
                            d.call(this, this.media.textTracks, o, ce.update.bind(this))
                        }
                        setTimeout(ce.update.bind(this), 0)
                    }
            },
            update: function() {
                var e = this,
                    t = ce.getTracks.call(this, !0),
                    i = this.captions,
                    n = i.active,
                    s = i.language,
                    a = i.meta,
                    o = i.currentTrackNode,
                    r = Boolean(t.find(function(e) {
                        return e.language === s
                    }));
                this.isHTML5 && this.isVideo && t.filter(function(e) {
                    return !a.get(e)
                }).forEach(function(t) {
                    e.debug.log("Track added", t), a.set(t, {
                        default: "showing" === t.mode
                    }), t.mode = "hidden", d.call(e, t, "cuechange", function() {
                        return ce.updateCues.call(e)
                    })
                }), (r && this.language !== s || !t.includes(o)) && (ce.setLanguage.call(this, s), ce.toggle.call(this, n && r)), M(this.elements.container, this.config.classNames.captions.enabled, !l.empty(t)), (this.config.controls || []).includes("settings") && this.config.settings.includes("captions") && oe.setCaptionsMenu.call(this)
            },
            toggle: function(e) {
                var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                if (this.supported.ui) {
                    var i = this.captions.toggled,
                        n = this.config.classNames.captions.active,
                        s = l.nullOrUndefined(e) ? !i : e;
                    if (s !== i) {
                        if (t || (this.captions.active = s, this.storage.set({
                                captions: s
                            })), !this.language && s && !t) {
                            var a = ce.getTracks.call(this),
                                o = ce.findTrack.call(this, [this.captions.language].concat(function(e) {
                                    if (Array.isArray(e)) {
                                        for (var t = 0, i = Array(e.length); t < e.length; t++) i[t] = e[t];
                                        return i
                                    }
                                    return Array.from(e)
                                }(this.captions.languages)), !0);
                            return this.captions.language = o.language, void ce.set.call(this, a.indexOf(o))
                        }
                        this.elements.buttons.captions && (this.elements.buttons.captions.pressed = s), M(this.elements.container, n, s), this.captions.toggled = s, oe.updateSetting.call(this, "captions"), f.call(this, this.media, s ? "captionsenabled" : "captionsdisabled")
                    }
                }
            },
            set: function(e) {
                var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                    i = ce.getTracks.call(this);
                if (-1 !== e)
                    if (l.number(e))
                        if (e in i) {
                            if (this.captions.currentTrack !== e) {
                                this.captions.currentTrack = e;
                                var n = i[e],
                                    s = (n || {}).language;
                                this.captions.currentTrackNode = n, oe.updateSetting.call(this, "captions"), t || (this.captions.language = s, this.storage.set({
                                    language: s
                                })), this.isVimeo && this.embed.enableTextTrack(s), f.call(this, this.media, "languagechange")
                            }
                            ce.toggle.call(this, !0, t), this.isHTML5 && this.isVideo && ce.updateCues.call(this)
                        } else this.debug.warn("Track not found", e);
                else this.debug.warn("Invalid caption argument", e);
                else ce.toggle.call(this, !1, t)
            },
            setLanguage: function(e) {
                var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                if (l.string(e)) {
                    var i = e.toLowerCase();
                    this.captions.language = i;
                    var n = ce.getTracks.call(this),
                        s = ce.findTrack.call(this, [i]);
                    ce.set.call(this, n.indexOf(s), t)
                } else this.debug.warn("Invalid language argument", e)
            },
            getTracks: function() {
                var e = this,
                    t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                return Array.from((this.media || {}).textTracks || []).filter(function(i) {
                    return !e.isHTML5 || t || e.captions.meta.has(i)
                }).filter(function(e) {
                    return ["captions", "subtitles"].includes(e.kind)
                })
            },
            findTrack: function(e) {
                var t = this,
                    i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    n = ce.getTracks.call(this),
                    s = function(e) {
                        return Number((t.captions.meta.get(e) || {}).default)
                    },
                    a = Array.from(n).sort(function(e, t) {
                        return s(t) - s(e)
                    }),
                    o = void 0;
                return e.every(function(e) {
                    return !(o = a.find(function(t) {
                        return t.language === e
                    }))
                }), o || (i ? a[0] : void 0)
            },
            getCurrentTrack: function() {
                return ce.getTracks.call(this)[this.currentTrack]
            },
            getLabel: function(e) {
                var t = e;
                return !l.track(t) && F.textTracks && this.captions.toggled && (t = ce.getCurrentTrack.call(this)), l.track(t) ? l.empty(t.label) ? l.empty(t.language) ? X("enabled", this.config) : e.language.toUpperCase() : t.label : X("disabled", this.config)
            },
            updateCues: function(e) {
                if (this.supported.ui)
                    if (l.element(this.elements.captions))
                        if (l.nullOrUndefined(e) || Array.isArray(e)) {
                            var t = e;
                            if (!t) {
                                var i = ce.getCurrentTrack.call(this);
                                t = Array.from((i || {}).activeCues || []).map(function(e) {
                                    return e.getCueAsHTML()
                                }).map(G)
                            }
                            var n = t.map(function(e) {
                                return e.trim()
                            }).join("\n");
                            if (n !== this.elements.captions.innerHTML) {
                                E(this.elements.captions);
                                var s = w("span", P(this.config.selectors.caption));
                                s.innerHTML = n, this.elements.captions.appendChild(s), f.call(this, this.media, "cuechange")
                            }
                        } else this.debug.warn("updateCues: Invalid input", e);
                else this.debug.warn("No captions element to render to")
            }
        },
        ue = {
            enabled: !0,
            title: "",
            debug: !1,
            autoplay: !1,
            autopause: !0,
            playsinline: !0,
            seekTime: 10,
            volume: 1,
            muted: !1,
            duration: null,
            displayDuration: !0,
            invertTime: !0,
            toggleInvert: !0,
            ratio: "16:9",
            clickToPlay: !0,
            hideControls: !0,
            resetOnEnd: !1,
            disableContextMenu: !0,
            loadSprite: !0,
            iconPrefix: "plyr",
            iconUrl: "https://cdn.plyr.io/3.3.12/plyr.svg",
            blankVideo: "https://cdn.plyr.io/static/blank.mp4",
            quality: {
                default: 576,
                options: [4320, 2880, 2160, 1440, 1080, 720, 576, 480, 360, 240]
            },
            loop: {
                active: !1
            },
            speed: {
                selected: 1,
                options: [.5, .75, 1, 1.25, 1.5, 1.75, 2]
            },
            keyboard: {
                focused: !0,
                global: !1
            },
            tooltips: {
                controls: !1,
                seek: !0
            },
            captions: {
                active: !1,
                language: "auto",
                update: !1
            },
            fullscreen: {
                enabled: !0,
                fallback: !0,
                iosNative: !1
            },
            storage: {
                enabled: !0,
                key: "plyr"
            },
            controls: ["play-large", "play", "progress", "current-time", "mute", "volume", "captions", "settings", "pip", "airplay", "fullscreen"],
            settings: ["captions", "quality", "speed"],
            i18n: {
                restart: "Restart",
                rewind: "Rewind {seektime}s",
                play: "Play",
                pause: "Pause",
                fastForward: "Forward {seektime}s",
                seek: "Seek",
                seekLabel: "{currentTime} of {duration}",
                played: "Played",
                buffered: "Buffered",
                currentTime: "Current time",
                duration: "Duration",
                volume: "Volume",
                mute: "Mute",
                unmute: "Unmute",
                enableCaptions: "Enable captions",
                disableCaptions: "Disable captions",
                enterFullscreen: "Enter fullscreen",
                exitFullscreen: "Exit fullscreen",
                frameTitle: "Player for {title}",
                captions: "Captions",
                settings: "Settings",
                menuBack: "Go back to previous menu",
                speed: "Speed",
                normal: "Normal",
                quality: "Quality",
                loop: "Loop",
                start: "Start",
                end: "End",
                all: "All",
                reset: "Reset",
                disabled: "Disabled",
                enabled: "Enabled",
                advertisement: "Ad",
                qualityBadge: {
                    2160: "4K",
                    1440: "HD",
                    1080: "HD",
                    720: "HD",
                    576: "SD",
                    480: "SD"
                }
            },
            urls: {
                vimeo: {
                    sdk: "https://player.vimeo.com/api/player.js",
                    iframe: "https://player.vimeo.com/video/{0}?{1}",
                    api: "https://vimeo.com/api/v2/video/{0}.json"
                },
                youtube: {
                    sdk: "https://www.youtube.com/iframe_api",
                    api: "https://www.googleapis.com/youtube/v3/videos?id={0}&key={1}&fields=items(snippet(title))&part=snippet"
                },
                googleIMA: {
                    sdk: "https://imasdk.googleapis.com/js/sdkloader/ima3.js"
                }
            },
            listeners: {
                seek: null,
                play: null,
                pause: null,
                restart: null,
                rewind: null,
                fastForward: null,
                mute: null,
                volume: null,
                captions: null,
                fullscreen: null,
                pip: null,
                airplay: null,
                speed: null,
                quality: null,
                loop: null,
                language: null
            },
            events: ["ended", "progress", "stalled", "playing", "waiting", "canplay", "canplaythrough", "loadstart", "loadeddata", "loadedmetadata", "timeupdate", "volumechange", "play", "pause", "error", "seeking", "seeked", "emptied", "ratechange", "cuechange", "enterfullscreen", "exitfullscreen", "captionsenabled", "captionsdisabled", "languagechange", "controlshidden", "controlsshown", "ready", "statechange", "qualitychange", "adsloaded", "adscontentpause", "adscontentresume", "adstarted", "adsmidpoint", "adscomplete", "adsallcomplete", "adsimpression", "adsclick"],
            selectors: {
                editable: "input, textarea, select, [contenteditable]",
                container: ".plyr",
                controls: {
                    container: null,
                    wrapper: ".plyr__controls"
                },
                labels: "[data-plyr]",
                buttons: {
                    play: '[data-plyr="play"]',
                    pause: '[data-plyr="pause"]',
                    restart: '[data-plyr="restart"]',
                    rewind: '[data-plyr="rewind"]',
                    fastForward: '[data-plyr="fast-forward"]',
                    mute: '[data-plyr="mute"]',
                    captions: '[data-plyr="captions"]',
                    fullscreen: '[data-plyr="fullscreen"]',
                    pip: '[data-plyr="pip"]',
                    airplay: '[data-plyr="airplay"]',
                    settings: '[data-plyr="settings"]',
                    loop: '[data-plyr="loop"]'
                },
                inputs: {
                    seek: '[data-plyr="seek"]',
                    volume: '[data-plyr="volume"]',
                    speed: '[data-plyr="speed"]',
                    language: '[data-plyr="language"]',
                    quality: '[data-plyr="quality"]'
                },
                display: {
                    currentTime: ".plyr__time--current",
                    duration: ".plyr__time--duration",
                    buffer: ".plyr__progress__buffer",
                    loop: ".plyr__progress__loop",
                    volume: ".plyr__volume--display"
                },
                progress: ".plyr__progress",
                captions: ".plyr__captions",
                caption: ".plyr__caption",
                menu: {
                    quality: ".js-plyr__menu__list--quality"
                }
            },
            classNames: {
                type: "plyr--{0}",
                provider: "plyr--{0}",
                video: "plyr__video-wrapper",
                embed: "plyr__video-embed",
                embedContainer: "plyr__video-embed__container",
                poster: "plyr__poster",
                posterEnabled: "plyr__poster-enabled",
                ads: "plyr__ads",
                control: "plyr__control",
                controlPressed: "plyr__control--pressed",
                playing: "plyr--playing",
                paused: "plyr--paused",
                stopped: "plyr--stopped",
                loading: "plyr--loading",
                hover: "plyr--hover",
                tooltip: "plyr__tooltip",
                cues: "plyr__cues",
                hidden: "plyr__sr-only",
                hideControls: "plyr--hide-controls",
                isIos: "plyr--is-ios",
                isTouch: "plyr--is-touch",
                uiSupported: "plyr--full-ui",
                noTransition: "plyr--no-transition",
                display: {
                    time: "plyr__time"
                },
                menu: {
                    value: "plyr__menu__value",
                    badge: "plyr__badge",
                    open: "plyr--menu-open"
                },
                captions: {
                    enabled: "plyr--captions-enabled",
                    active: "plyr--captions-active"
                },
                fullscreen: {
                    enabled: "plyr--fullscreen-enabled",
                    fallback: "plyr--fullscreen-fallback"
                },
                pip: {
                    supported: "plyr--pip-supported",
                    active: "plyr--pip-active"
                },
                airplay: {
                    supported: "plyr--airplay-supported",
                    active: "plyr--airplay-active"
                },
                tabFocus: "plyr__tab-focus"
            },
            attributes: {
                embed: {
                    provider: "data-plyr-provider",
                    id: "data-plyr-embed-id"
                }
            },
            keys: {
                google: null
            },
            ads: {
                enabled: !1,
                publisherId: ""
            }
        },
        de = {
            html5: "html5",
            youtube: "youtube",
            vimeo: "vimeo"
        },
        he = {
            audio: "audio",
            video: "video"
        };
    var pe = function() {},
        fe = function() {
            function e() {
                var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                m(this, e), this.enabled = window.console && t, this.enabled && this.log("Debugging enabled")
            }
            return g(e, [{
                key: "log",
                get: function() {
                    return this.enabled ? Function.prototype.bind.call(console.log, console) : pe
                }
            }, {
                key: "warn",
                get: function() {
                    return this.enabled ? Function.prototype.bind.call(console.warn, console) : pe
                }
            }, {
                key: "error",
                get: function() {
                    return this.enabled ? Function.prototype.bind.call(console.error, console) : pe
                }
            }]), e
        }();

    function me() {
        if (this.enabled) {
            var e = this.player.elements.buttons.fullscreen;
            l.element(e) && (e.pressed = this.active), f.call(this.player, this.target, this.active ? "enterfullscreen" : "exitfullscreen", !0), V.isIos || function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                    t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                if (l.element(e)) {
                    var i = x.call(this, "button:not(:disabled), input:not(:disabled), [tabindex]"),
                        n = i[0],
                        s = i[i.length - 1];
                    u.call(this, this.elements.container, "keydown", function(e) {
                        if ("Tab" === e.key && 9 === e.keyCode) {
                            var t = document.activeElement;
                            t !== s || e.shiftKey ? t === n && e.shiftKey && (s.focus(), e.preventDefault()) : (n.focus(), e.preventDefault())
                        }
                    }, t, !1)
                }
            }.call(this.player, this.target, this.active)
        }
    }

    function ge() {
        var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        e ? this.scrollPosition = {
            x: window.scrollX || 0,
            y: window.scrollY || 0
        } : window.scrollTo(this.scrollPosition.x, this.scrollPosition.y), document.body.style.overflow = e ? "hidden" : "", M(this.target, this.player.config.classNames.fullscreen.fallback, e), me.call(this)
    }
    var ye = function() {
        function e(t) {
            var i = this;
            m(this, e), this.player = t, this.prefix = e.prefix, this.property = e.property, this.scrollPosition = {
                x: 0,
                y: 0
            }, d.call(this.player, document, "ms" === this.prefix ? "MSFullscreenChange" : this.prefix + "fullscreenchange", function() {
                me.call(i)
            }), d.call(this.player, this.player.elements.container, "dblclick", function(e) {
                l.element(i.player.elements.controls) && i.player.elements.controls.contains(e.target) || i.toggle()
            }), this.update()
        }
        return g(e, [{
            key: "update",
            value: function() {
                this.enabled ? this.player.debug.log((e.native ? "Native" : "Fallback") + " fullscreen enabled") : this.player.debug.log("Fullscreen not supported and fallback disabled"), M(this.player.elements.container, this.player.config.classNames.fullscreen.enabled, this.enabled)
            }
        }, {
            key: "enter",
            value: function() {
                this.enabled && (V.isIos && this.player.config.fullscreen.iosNative ? this.target.webkitEnterFullscreen() : e.native ? this.prefix ? l.empty(this.prefix) || this.target[this.prefix + "Request" + this.property]() : this.target.requestFullscreen() : ge.call(this, !0))
            }
        }, {
            key: "exit",
            value: function() {
                if (this.enabled)
                    if (V.isIos && this.player.config.fullscreen.iosNative) this.target.webkitExitFullscreen(), this.player.play();
                    else if (e.native)
                    if (this.prefix) {
                        if (!l.empty(this.prefix)) {
                            var t = "moz" === this.prefix ? "Cancel" : "Exit";
                            document["" + this.prefix + t + this.property]()
                        }
                    } else(document.cancelFullScreen || document.exitFullscreen).call(document);
                else ge.call(this, !1)
            }
        }, {
            key: "toggle",
            value: function() {
                this.active ? this.exit() : this.enter()
            }
        }, {
            key: "enabled",
            get: function() {
                return (e.native || this.player.config.fullscreen.fallback) && this.player.config.fullscreen.enabled && this.player.supported.ui && this.player.isVideo
            }
        }, {
            key: "active",
            get: function() {
                return !!this.enabled && (e.native ? (this.prefix ? document["" + this.prefix + this.property + "Element"] : document.fullscreenElement) === this.target : N(this.target, this.player.config.classNames.fullscreen.fallback))
            }
        }, {
            key: "target",
            get: function() {
                return V.isIos && this.player.config.fullscreen.iosNative ? this.player.media : this.player.elements.container
            }
        }], [{
            key: "native",
            get: function() {
                return !!(document.fullscreenEnabled || document.webkitFullscreenEnabled || document.mozFullScreenEnabled || document.msFullscreenEnabled)
            }
        }, {
            key: "prefix",
            get: function() {
                if (l.function(document.exitFullscreen)) return "";
                var e = "";
                return ["webkit", "moz", "ms"].some(function(t) {
                    return !(!l.function(document[t + "ExitFullscreen"]) && !l.function(document[t + "CancelFullScreen"])) && (e = t, !0)
                }), e
            }
        }, {
            key: "property",
            get: function() {
                return "moz" === this.prefix ? "FullScreen" : "Fullscreen"
            }
        }]), e
    }();

    function ve(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        return new Promise(function(i, n) {
            var s = new Image,
                a = function() {
                    delete s.onload, delete s.onerror, (s.naturalWidth >= t ? i : n)(s)
                };
            Object.assign(s, {
                onload: a,
                onerror: a,
                src: e
            })
        })
    }
    var be = {
            addStyleHook: function() {
                M(this.elements.container, this.config.selectors.container.replace(".", ""), !0), M(this.elements.container, this.config.classNames.uiSupported, this.supported.ui)
            },
            toggleNativeControls: function() {
                arguments.length > 0 && void 0 !== arguments[0] && arguments[0] && this.isHTML5 ? this.media.setAttribute("controls", "") : this.media.removeAttribute("controls")
            },
            build: function() {
                var e = this;
                if (this.listeners.media(), !this.supported.ui) return this.debug.warn("Basic support only for " + this.provider + " " + this.type), void be.toggleNativeControls.call(this, !0);
                l.element(this.elements.controls) || (oe.inject.call(this), this.listeners.controls()), be.toggleNativeControls.call(this), this.isHTML5 && ce.setup.call(this), this.volume = null, this.muted = null, this.speed = null, this.loop = null, this.quality = null, oe.updateVolume.call(this), oe.timeUpdate.call(this), be.checkPlaying.call(this), M(this.elements.container, this.config.classNames.pip.supported, F.pip && this.isHTML5 && this.isVideo), M(this.elements.container, this.config.classNames.airplay.supported, F.airplay && this.isHTML5), M(this.elements.container, this.config.classNames.isIos, V.isIos), M(this.elements.container, this.config.classNames.isTouch, this.touch), this.ready = !0, setTimeout(function() {
                    f.call(e, e.media, "ready")
                }, 0), be.setTitle.call(this), this.poster && be.setPoster.call(this, this.poster, !1).catch(function() {}), this.config.duration && oe.durationUpdate.call(this)
            },
            setTitle: function() {
                var e = X("play", this.config);
                if (l.string(this.config.title) && !l.empty(this.config.title) && (e += ", " + this.config.title), Array.from(this.elements.buttons.play || []).forEach(function(t) {
                        t.setAttribute("aria-label", e)
                    }), this.isEmbed) {
                    var t = _.call(this, "iframe");
                    if (!l.element(t)) return;
                    var i = l.empty(this.config.title) ? "video" : this.config.title,
                        n = X("frameTitle", this.config);
                    t.setAttribute("title", n.replace("{title}", i))
                }
            },
            togglePoster: function(e) {
                M(this.elements.container, this.config.classNames.posterEnabled, e)
            },
            setPoster: function(e) {
                var t = this;
                return arguments.length > 1 && void 0 !== arguments[1] && !arguments[1] || !this.poster ? (this.media.setAttribute("poster", e), function() {
                    var e = this;
                    return new Promise(function(t) {
                        return e.ready ? setTimeout(t, 0) : d.call(e, e.elements.container, "ready", t)
                    }).then(function() {})
                }.call(this).then(function() {
                    return ve(e)
                }).catch(function(i) {
                    throw e === t.poster && be.togglePoster.call(t, !1), i
                }).then(function() {
                    if (e !== t.poster) throw new Error("setPoster cancelled by later call to setPoster")
                }).then(function() {
                    return Object.assign(t.elements.poster.style, {
                        backgroundImage: "url('" + e + "')",
                        backgroundSize: ""
                    }), be.togglePoster.call(t, !0), e
                })) : Promise.reject(new Error("Poster already set"))
            },
            checkPlaying: function(e) {
                var t = this;
                M(this.elements.container, this.config.classNames.playing, this.playing), M(this.elements.container, this.config.classNames.paused, this.paused), M(this.elements.container, this.config.classNames.stopped, this.stopped), Array.from(this.elements.buttons.play || []).forEach(function(e) {
                    e.pressed = t.playing
                }), l.event(e) && "timeupdate" === e.type || be.toggleControls.call(this)
            },
            checkLoading: function(e) {
                var t = this;
                this.loading = ["stalled", "waiting"].includes(e.type), clearTimeout(this.timers.loading), this.timers.loading = setTimeout(function() {
                    M(t.elements.container, t.config.classNames.loading, t.loading), be.toggleControls.call(t)
                }, this.loading ? 250 : 0)
            },
            toggleControls: function(e) {
                var t = this.elements.controls;
                t && this.config.hideControls && this.toggleControls(Boolean(e || this.loading || this.paused || t.pressed || t.hover))
            }
        },
        ke = function() {
            function e(t) {
                m(this, e), this.player = t, this.lastKey = null, this.focusTimer = null, this.lastKeyDown = null, this.handleKey = this.handleKey.bind(this), this.toggleMenu = this.toggleMenu.bind(this), this.setTabFocus = this.setTabFocus.bind(this), this.firstTouch = this.firstTouch.bind(this)
            }
            return g(e, [{
                key: "handleKey",
                value: function(e) {
                    var t = this.player,
                        i = t.elements,
                        n = e.keyCode ? e.keyCode : e.which,
                        s = "keydown" === e.type,
                        a = s && n === this.lastKey;
                    if (!(e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) && l.number(n)) {
                        if (s) {
                            var o = document.activeElement;
                            if (l.element(o)) {
                                var r = t.config.selectors.editable;
                                if (o !== i.inputs.seek && L(o, r)) return;
                                if (32 === e.which && L(o, 'button, [role^="menuitem"]')) return
                            }
                            switch ([32, 37, 38, 39, 40, 48, 49, 50, 51, 52, 53, 54, 56, 57, 67, 70, 73, 75, 76, 77, 79].includes(n) && (e.preventDefault(), e.stopPropagation()), n) {
                                case 48:
                                case 49:
                                case 50:
                                case 51:
                                case 52:
                                case 53:
                                case 54:
                                case 55:
                                case 56:
                                case 57:
                                    a || (t.currentTime = t.duration / 10 * (n - 48));
                                    break;
                                case 32:
                                case 75:
                                    a || t.togglePlay();
                                    break;
                                case 38:
                                    t.increaseVolume(.1);
                                    break;
                                case 40:
                                    t.decreaseVolume(.1);
                                    break;
                                case 77:
                                    a || (t.muted = !t.muted);
                                    break;
                                case 39:
                                    t.forward();
                                    break;
                                case 37:
                                    t.rewind();
                                    break;
                                case 70:
                                    t.fullscreen.toggle();
                                    break;
                                case 67:
                                    a || t.toggleCaptions();
                                    break;
                                case 76:
                                    t.loop = !t.loop
                            }!t.fullscreen.enabled && t.fullscreen.active && 27 === n && t.fullscreen.toggle(), this.lastKey = n
                        } else this.lastKey = null
                    }
                }
            }, {
                key: "toggleMenu",
                value: function(e) {
                    oe.toggleMenu.call(this.player, e)
                }
            }, {
                key: "firstTouch",
                value: function() {
                    var e = this.player,
                        t = e.elements;
                    e.touch = !0, M(t.container, e.config.classNames.isTouch, !0)
                }
            }, {
                key: "setTabFocus",
                value: function(e) {
                    var t = this.player,
                        i = t.elements;
                    if (clearTimeout(this.focusTimer), "keydown" !== e.type || 9 === e.which) {
                        "keydown" === e.type && (this.lastKeyDown = e.timeStamp);
                        var n, s = e.timeStamp - this.lastKeyDown <= 20;
                        if ("focus" !== e.type || s) n = t.config.classNames.tabFocus, M(x.call(t, "." + n), n, !1), this.focusTimer = setTimeout(function() {
                            var e = document.activeElement;
                            i.container.contains(e) && M(document.activeElement, t.config.classNames.tabFocus, !0)
                        }, 10)
                    }
                }
            }, {
                key: "global",
                value: function() {
                    var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
                        t = this.player;
                    t.config.keyboard.global && u.call(t, window, "keydown keyup", this.handleKey, e, !1), u.call(t, document.body, "click", this.toggleMenu, e), p.call(t, document.body, "touchstart", this.firstTouch), u.call(t, document.body, "keydown focus blur", this.setTabFocus, e, !1, !0)
                }
            }, {
                key: "container",
                value: function() {
                    var e = this.player,
                        t = e.elements;
                    !e.config.keyboard.global && e.config.keyboard.focused && d.call(e, t.container, "keydown keyup", this.handleKey, !1), d.call(e, t.container, "mousemove mouseleave touchstart touchmove enterfullscreen exitfullscreen", function(i) {
                        var n = t.controls;
                        n && "enterfullscreen" === i.type && (n.pressed = !1, n.hover = !1);
                        var s = 0;
                        ["touchstart", "touchmove", "mousemove"].includes(i.type) && (be.toggleControls.call(e, !0), s = e.touch ? 3e3 : 2e3), clearTimeout(e.timers.controls), e.timers.controls = setTimeout(function() {
                            return be.toggleControls.call(e, !1)
                        }, s)
                    })
                }
            }, {
                key: "media",
                value: function() {
                    var e = this.player,
                        t = e.elements;
                    if (d.call(e, e.media, "timeupdate seeking seeked", function(t) {
                            return oe.timeUpdate.call(e, t)
                        }), d.call(e, e.media, "durationchange loadeddata loadedmetadata", function(t) {
                            return oe.durationUpdate.call(e, t)
                        }), d.call(e, e.media, "canplay", function() {
                            S(t.volume, !e.hasAudio), S(t.buttons.mute, !e.hasAudio)
                        }), d.call(e, e.media, "ended", function() {
                            e.isHTML5 && e.isVideo && e.config.resetOnEnd && e.restart()
                        }), d.call(e, e.media, "progress playing seeking seeked", function(t) {
                            return oe.updateProgress.call(e, t)
                        }), d.call(e, e.media, "volumechange", function(t) {
                            return oe.updateVolume.call(e, t)
                        }), d.call(e, e.media, "playing play pause ended emptied timeupdate", function(t) {
                            return be.checkPlaying.call(e, t)
                        }), d.call(e, e.media, "waiting canplay seeked playing", function(t) {
                            return be.checkLoading.call(e, t)
                        }), d.call(e, e.media, "playing", function() {
                            e.ads && e.ads.enabled && !e.ads.initialized && e.ads.managerPromise.then(function() {
                                return e.ads.play()
                            }).catch(function() {
                                return e.play()
                            })
                        }), e.supported.ui && e.config.clickToPlay && !e.isAudio) {
                        var i = _.call(e, "." + e.config.classNames.video);
                        if (!l.element(i)) return;
                        d.call(e, t.container, "click touchstart", function(n) {
                            ([t.container, i].includes(n.target) || i.contains(n.target)) && (e.config.hideControls && e.touch && N(t.container, e.config.classNames.hideControls) || (e.ended ? (e.restart(), e.play()) : e.togglePlay()))
                        })
                    }
                    e.supported.ui && e.config.disableContextMenu && d.call(e, t.wrapper, "contextmenu", function(e) {
                        e.preventDefault()
                    }, !1), d.call(e, e.media, "volumechange", function() {
                        e.storage.set({
                            volume: e.volume,
                            muted: e.muted
                        })
                    }), d.call(e, e.media, "ratechange", function() {
                        oe.updateSetting.call(e, "speed"), e.storage.set({
                            speed: e.speed
                        })
                    }), d.call(e, e.media, "qualitychange", function(t) {
                        oe.updateSetting.call(e, "quality", null, t.detail.quality)
                    });
                    var n = e.config.events.concat(["keyup", "keydown"]).join(" ");
                    d.call(e, e.media, n, function(i) {
                        var n = i.detail,
                            s = void 0 === n ? {} : n;
                        "error" === i.type && (s = e.media.error), f.call(e, t.container, i.type, !0, s)
                    })
                }
            }, {
                key: "proxy",
                value: function(e, t, i) {
                    var n = this.player,
                        s = n.config.listeners[i],
                        a = !0;
                    l.function(s) && (a = s.call(n, e)), a && l.function(t) && t.call(n, e)
                }
            }, {
                key: "bind",
                value: function(e, t, i, n) {
                    var s = this,
                        a = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
                        o = this.player,
                        r = o.config.listeners[n],
                        c = l.function(r);
                    d.call(o, e, t, function(e) {
                        return s.proxy(e, i, n)
                    }, a && !c)
                }
            }, {
                key: "controls",
                value: function() {
                    var e = this,
                        t = this.player,
                        i = t.elements,
                        n = V.isIE ? "change" : "input";
                    if (i.buttons.play && Array.from(i.buttons.play).forEach(function(i) {
                            e.bind(i, "click", t.togglePlay, "play")
                        }), this.bind(i.buttons.restart, "click", t.restart, "restart"), this.bind(i.buttons.rewind, "click", t.rewind, "rewind"), this.bind(i.buttons.fastForward, "click", t.forward, "fastForward"), this.bind(i.buttons.mute, "click", function() {
                            t.muted = !t.muted
                        }, "mute"), this.bind(i.buttons.captions, "click", function() {
                            return t.toggleCaptions()
                        }), this.bind(i.buttons.fullscreen, "click", function() {
                            t.fullscreen.toggle()
                        }, "fullscreen"), this.bind(i.buttons.pip, "click", function() {
                            t.pip = "toggle"
                        }, "pip"), this.bind(i.buttons.airplay, "click", t.airplay, "airplay"), this.bind(i.buttons.settings, "click", function(e) {
                            e.stopPropagation(), oe.toggleMenu.call(t, e)
                        }), this.bind(i.buttons.settings, "keyup", function(e) {
                            var i = e.which;
                            [13, 32].includes(i) && (13 !== i ? (e.preventDefault(), e.stopPropagation(), oe.toggleMenu.call(t, e)) : oe.focusFirstMenuItem.call(t, null, !0))
                        }, null, !1), this.bind(i.settings.menu, "keydown", function(e) {
                            27 === e.which && oe.toggleMenu.call(t, e)
                        }), this.bind(i.inputs.seek, "mousedown mousemove", function(e) {
                            var t = i.progress.getBoundingClientRect(),
                                n = 100 / t.width * (e.pageX - t.left);
                            e.currentTarget.setAttribute("seek-value", n)
                        }), this.bind(i.inputs.seek, "mousedown mouseup keydown keyup touchstart touchend", function(e) {
                            var i = e.currentTarget,
                                n = e.keyCode ? e.keyCode : e.which;
                            if (!l.keyboardEvent(e) || 39 === n || 37 === n) {
                                var s = i.hasAttribute("play-on-seeked"),
                                    a = ["mouseup", "touchend", "keyup"].includes(e.type);
                                s && a ? (i.removeAttribute("play-on-seeked"), t.play()) : !a && t.playing && (i.setAttribute("play-on-seeked", ""), t.pause())
                            }
                        }), V.isIos) {
                        var s = x.call(t, 'input[type="range"]');
                        Array.from(s).forEach(function(t) {
                            return e.bind(t, n, function(e) {
                                return B(e.target)
                            })
                        })
                    }
                    this.bind(i.inputs.seek, n, function(e) {
                        var i = e.currentTarget,
                            n = i.getAttribute("seek-value");
                        l.empty(n) && (n = i.value), i.removeAttribute("seek-value"), t.currentTime = n / i.max * t.duration
                    }, "seek"), this.bind(i.progress, "mouseenter mouseleave mousemove", function(e) {
                        return oe.updateSeekTooltip.call(t, e)
                    }), V.isWebkit && Array.from(x.call(t, 'input[type="range"]')).forEach(function(i) {
                        e.bind(i, "input", function(e) {
                            return oe.updateRangeFill.call(t, e.target)
                        })
                    }), t.config.toggleInvert && !l.element(i.display.duration) && this.bind(i.display.currentTime, "click", function() {
                        0 !== t.currentTime && (t.config.invertTime = !t.config.invertTime, oe.timeUpdate.call(t))
                    }), this.bind(i.inputs.volume, n, function(e) {
                        t.volume = e.target.value
                    }, "volume"), this.bind(i.controls, "mouseenter mouseleave", function(e) {
                        i.controls.hover = !t.touch && "mouseenter" === e.type
                    }), this.bind(i.controls, "mousedown mouseup touchstart touchend touchcancel", function(e) {
                        i.controls.pressed = ["mousedown", "touchstart"].includes(e.type)
                    }), this.bind(i.controls, "focusin focusout", function(i) {
                        var n = t.config,
                            s = t.elements,
                            a = t.timers,
                            o = "focusin" === i.type;
                        if (M(s.controls, n.classNames.noTransition, o), be.toggleControls.call(t, o), o) {
                            setTimeout(function() {
                                M(s.controls, n.classNames.noTransition, !1)
                            }, 0);
                            var r = e.touch ? 3e3 : 4e3;
                            clearTimeout(a.controls), a.controls = setTimeout(function() {
                                return be.toggleControls.call(t, !1)
                            }, r)
                        }
                    }), this.bind(i.inputs.volume, "wheel", function(e) {
                        var i = e.webkitDirectionInvertedFromDevice,
                            n = [e.deltaX, -e.deltaY].map(function(e) {
                                return i ? -e : e
                            }),
                            s = v(n, 2),
                            a = s[0],
                            o = s[1],
                            r = Math.sign(Math.abs(a) > Math.abs(o) ? a : o);
                        t.increaseVolume(r / 50);
                        var l = t.media.volume;
                        (1 === r && l < 1 || -1 === r && l > 0) && e.preventDefault()
                    }, "volume", !1)
                }
            }]), e
        }();
    "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self && self;
    var we, Te = (function(e, t) {
        var i;
        i = function() {
            var e = function() {},
                t = {},
                i = {},
                n = {};

            function s(e, t) {
                if (e) {
                    var s = n[e];
                    if (i[e] = t, s)
                        for (; s.length;) s[0](e, t), s.splice(0, 1)
                }
            }

            function a(t, i) {
                t.call && (t = {
                    success: t
                }), i.length ? (t.error || e)(i) : (t.success || e)(t)
            }

            function o(t, i, n, s) {
                var a, r, l = document,
                    c = n.async,
                    u = (n.numRetries || 0) + 1,
                    d = n.before || e,
                    h = t.replace(/^(css|img)!/, "");
                s = s || 0, /(^css!|\.css$)/.test(t) ? (a = !0, (r = l.createElement("link")).rel = "stylesheet", r.href = h) : /(^img!|\.(png|gif|jpg|svg)$)/.test(t) ? (r = l.createElement("img")).src = h : ((r = l.createElement("script")).src = t, r.async = void 0 === c || c), r.onload = r.onerror = r.onbeforeload = function(e) {
                    var l = e.type[0];
                    if (a && "hideFocus" in r) try {
                        r.sheet.cssText.length || (l = "e")
                    } catch (e) {
                        l = "e"
                    }
                    if ("e" == l && (s += 1) < u) return o(t, i, n, s);
                    i(t, l, e.defaultPrevented)
                }, !1 !== d(t, r) && l.head.appendChild(r)
            }

            function r(e, i, n) {
                var r, l;
                if (i && i.trim && (r = i), l = (r ? n : i) || {}, r) {
                    if (r in t) throw "LoadJS";
                    t[r] = !0
                }! function(e, t, i) {
                    var n, s, a = (e = e.push ? e : [e]).length,
                        r = a,
                        l = [];
                    for (n = function(e, i, n) {
                            if ("e" == i && l.push(e), "b" == i) {
                                if (!n) return;
                                l.push(e)
                            }--a || t(l)
                        }, s = 0; s < r; s++) o(e[s], n, i)
                }(e, function(e) {
                    a(l, e), s(r, e)
                }, l)
            }
            return r.ready = function(e, t) {
                return function(e, t) {
                    e = e.push ? e : [e];
                    var s, a, o, r = [],
                        l = e.length,
                        c = l;
                    for (s = function(e, i) {
                            i.length && r.push(e), --c || t(r)
                        }; l--;) a = e[l], (o = i[a]) ? s(a, o) : (n[a] = n[a] || []).push(s)
                }(e, function(e) {
                    a(t, e)
                }), r
            }, r.done = function(e) {
                s(e, [])
            }, r.reset = function() {
                t = {}, i = {}, n = {}
            }, r.isDefined = function(e) {
                return e in t
            }, r
        }, e.exports = i()
    }(we = {
        exports: {}
    }, we.exports), we.exports);

    function Ae(e) {
        return new Promise(function(t, i) {
            Te(e, {
                success: t,
                error: i
            })
        })
    }

    function Ee(e) {
        e && !this.embed.hasPlayed && (this.embed.hasPlayed = !0), this.media.paused === e && (this.media.paused = !e, f.call(this, this.media, e ? "play" : "pause"))
    }
    var Ce = {
        setup: function() {
            var e = this;
            M(this.elements.wrapper, this.config.classNames.embed, !0), Ce.setAspectRatio.call(this), l.object(window.Vimeo) ? Ce.ready.call(this) : Ae(this.config.urls.vimeo.sdk).then(function() {
                Ce.ready.call(e)
            }).catch(function(t) {
                e.debug.warn("Vimeo API failed to load", t)
            })
        },
        setAspectRatio: function(e) {
            var t = (l.string(e) ? e : this.config.ratio).split(":"),
                i = v(t, 2),
                n = 100 / i[0] * i[1];
            if (this.elements.wrapper.style.paddingBottom = n + "%", this.supported.ui) {
                var s = (240 - n) / 4.8;
                this.media.style.transform = "translateY(-" + s + "%)"
            }
        },
        ready: function() {
            var e = this,
                t = this,
                i = le({
                    loop: t.config.loop.active,
                    autoplay: t.autoplay,
                    byline: !1,
                    portrait: !1,
                    title: !1,
                    speed: !0,
                    transparent: 0,
                    gesture: "media",
                    playsinline: !this.config.fullscreen.iosNative
                }),
                n = t.media.getAttribute("src");
            l.empty(n) && (n = t.media.getAttribute(t.config.attributes.embed.id));
            var s, a = (s = n, l.empty(s) ? null : l.number(Number(s)) ? s : s.match(/^.*(vimeo.com\/|video\/)(\d+).*/) ? RegExp.$2 : s),
                o = w("iframe"),
                r = Y(t.config.urls.vimeo.iframe, a, i);
            o.setAttribute("src", r), o.setAttribute("allowfullscreen", ""), o.setAttribute("allowtransparency", ""), o.setAttribute("allow", "autoplay");
            var c = w("div", {
                poster: t.poster,
                class: t.config.classNames.embedContainer
            });
            c.appendChild(o), t.media = C(c, t.media), ee(Y(t.config.urls.vimeo.api, a), "json").then(function(e) {
                if (!l.empty(e)) {
                    var i = new URL(e[0].thumbnail_large);
                    i.pathname = i.pathname.split("_")[0] + ".jpg", be.setPoster.call(t, i.href).catch(function() {})
                }
            }), t.embed = new window.Vimeo.Player(o, {
                autopause: t.config.autopause,
                muted: t.muted
            }), t.media.paused = !0, t.media.currentTime = 0, t.supported.ui && t.embed.disableTextTrack(), t.media.play = function() {
                return Ee.call(t, !0), t.embed.play()
            }, t.media.pause = function() {
                return Ee.call(t, !1), t.embed.pause()
            }, t.media.stop = function() {
                t.pause(), t.currentTime = 0
            };
            var u = t.media.currentTime;
            Object.defineProperty(t.media, "currentTime", {
                get: function() {
                    return u
                },
                set: function(e) {
                    var i = t.embed,
                        n = t.media,
                        s = t.paused,
                        a = t.volume,
                        o = s && !i.hasPlayed;
                    n.seeking = !0, f.call(t, n, "seeking"), Promise.resolve(o && i.setVolume(0)).then(function() {
                        return i.setCurrentTime(e)
                    }).then(function() {
                        return o && i.pause()
                    }).then(function() {
                        return o && i.setVolume(a)
                    }).catch(function() {})
                }
            });
            var d = t.config.speed.selected;
            Object.defineProperty(t.media, "playbackRate", {
                get: function() {
                    return d
                },
                set: function(e) {
                    t.embed.setPlaybackRate(e).then(function() {
                        d = e, f.call(t, t.media, "ratechange")
                    }).catch(function(e) {
                        "Error" === e.name && oe.setSpeedMenu.call(t, [])
                    })
                }
            });
            var h = t.config.volume;
            Object.defineProperty(t.media, "volume", {
                get: function() {
                    return h
                },
                set: function(e) {
                    t.embed.setVolume(e).then(function() {
                        h = e, f.call(t, t.media, "volumechange")
                    })
                }
            });
            var p = t.config.muted;
            Object.defineProperty(t.media, "muted", {
                get: function() {
                    return p
                },
                set: function(e) {
                    var i = !!l.boolean(e) && e;
                    t.embed.setVolume(i ? 0 : t.config.volume).then(function() {
                        p = i, f.call(t, t.media, "volumechange")
                    })
                }
            });
            var m = t.config.loop;
            Object.defineProperty(t.media, "loop", {
                get: function() {
                    return m
                },
                set: function(e) {
                    var i = l.boolean(e) ? e : t.config.loop.active;
                    t.embed.setLoop(i).then(function() {
                        m = i
                    })
                }
            });
            var g = void 0;
            t.embed.getVideoUrl().then(function(e) {
                g = e
            }).catch(function(t) {
                e.debug.warn(t)
            }), Object.defineProperty(t.media, "currentSrc", {
                get: function() {
                    return g
                }
            }), Object.defineProperty(t.media, "ended", {
                get: function() {
                    return t.currentTime === t.duration
                }
            }), Promise.all([t.embed.getVideoWidth(), t.embed.getVideoHeight()]).then(function(t) {
                var i = function(e, t) {
                    var i = function e(t, i) {
                        return 0 === i ? t : e(i, t % i)
                    }(e, t);
                    return e / i + ":" + t / i
                }(t[0], t[1]);
                Ce.setAspectRatio.call(e, i)
            }), t.embed.setAutopause(t.config.autopause).then(function(e) {
                t.config.autopause = e
            }), t.embed.getVideoTitle().then(function(i) {
                t.config.title = i, be.setTitle.call(e)
            }), t.embed.getCurrentTime().then(function(e) {
                u = e, f.call(t, t.media, "timeupdate")
            }), t.embed.getDuration().then(function(e) {
                t.media.duration = e, f.call(t, t.media, "durationchange")
            }), t.embed.getTextTracks().then(function(e) {
                t.media.textTracks = e, ce.setup.call(t)
            }), t.embed.on("cuechange", function(e) {
                var i = e.cues,
                    n = (void 0 === i ? [] : i).map(function(e) {
                        return t = e.text, i = document.createDocumentFragment(), n = document.createElement("div"), i.appendChild(n), n.innerHTML = t, i.firstChild.innerText;
                        var t, i, n
                    });
                ce.updateCues.call(t, n)
            }), t.embed.on("loaded", function() {
                (t.embed.getPaused().then(function(e) {
                    Ee.call(t, !e), e || f.call(t, t.media, "playing")
                }), l.element(t.embed.element) && t.supported.ui) && t.embed.element.setAttribute("tabindex", -1)
            }), t.embed.on("play", function() {
                Ee.call(t, !0), f.call(t, t.media, "playing")
            }), t.embed.on("pause", function() {
                Ee.call(t, !1)
            }), t.embed.on("timeupdate", function(e) {
                t.media.seeking = !1, u = e.seconds, f.call(t, t.media, "timeupdate")
            }), t.embed.on("progress", function(e) {
                t.media.buffered = e.percent, f.call(t, t.media, "progress"), 1 === parseInt(e.percent, 10) && f.call(t, t.media, "canplaythrough"), t.embed.getDuration().then(function(e) {
                    e !== t.media.duration && (t.media.duration = e, f.call(t, t.media, "durationchange"))
                })
            }), t.embed.on("seeked", function() {
                t.media.seeking = !1, f.call(t, t.media, "seeked")
            }), t.embed.on("ended", function() {
                t.media.paused = !0, f.call(t, t.media, "ended")
            }), t.embed.on("error", function(e) {
                t.media.error = e, f.call(t, t.media, "error")
            }), setTimeout(function() {
                return be.build.call(t)
            }, 0)
        }
    };

    function Pe(e) {
        e && !this.embed.hasPlayed && (this.embed.hasPlayed = !0), this.media.paused === e && (this.media.paused = !e, f.call(this, this.media, e ? "play" : "pause"))
    }
    var Se, Me = {
            setup: function() {
                var e = this;
                M(this.elements.wrapper, this.config.classNames.embed, !0), Me.setAspectRatio.call(this), l.object(window.YT) && l.function(window.YT.Player) ? Me.ready.call(this) : (Ae(this.config.urls.youtube.sdk).catch(function(t) {
                    e.debug.warn("YouTube API failed to load", t)
                }), window.onYouTubeReadyCallbacks = window.onYouTubeReadyCallbacks || [], window.onYouTubeReadyCallbacks.push(function() {
                    Me.ready.call(e)
                }), window.onYouTubeIframeAPIReady = function() {
                    window.onYouTubeReadyCallbacks.forEach(function(e) {
                        e()
                    })
                })
            },
            getTitle: function(e) {
                var t = this;
                if (l.function(this.embed.getVideoData)) {
                    var i = this.embed.getVideoData().title;
                    if (l.empty(i)) return this.config.title = i, void be.setTitle.call(this)
                }
                var n = this.config.keys.google;
                l.string(n) && !l.empty(n) && ee(Y(this.config.urls.youtube.api, e, n)).then(function(e) {
                    l.object(e) && (t.config.title = e.items[0].snippet.title, be.setTitle.call(t))
                }).catch(function() {})
            },
            setAspectRatio: function() {
                var e = this.config.ratio.split(":");
                this.elements.wrapper.style.paddingBottom = 100 / e[0] * e[1] + "%"
            },
            ready: function() {
                var e = this,
                    t = e.media.getAttribute("id");
                if (l.empty(t) || !t.startsWith("youtube-")) {
                    var i = e.media.getAttribute("src");
                    l.empty(i) && (i = e.media.getAttribute(this.config.attributes.embed.id));
                    var n, s = (n = i, l.empty(n) ? null : n.match(/^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/) ? RegExp.$2 : n),
                        a = e.provider + "-" + Math.floor(1e4 * Math.random()),
                        o = w("div", {
                            id: a,
                            poster: e.poster
                        });
                    e.media = C(o, e.media);
                    var r = function(e) {
                        return "https://img.youtube.com/vi/" + s + "/" + e + "default.jpg"
                    };
                    ve(r("maxres"), 121).catch(function() {
                        return ve(r("sd"), 121)
                    }).catch(function() {
                        return ve(r("hq"))
                    }).then(function(t) {
                        return be.setPoster.call(e, t.src)
                    }).then(function(t) {
                        t.includes("maxres") || (e.elements.poster.style.backgroundSize = "cover")
                    }).catch(function() {}), e.embed = new window.YT.Player(a, {
                        videoId: s,
                        playerVars: {
                            autoplay: e.config.autoplay ? 1 : 0,
                            hl: e.config.hl,
                            controls: e.supported.ui ? 0 : 1,
                            rel: 0,
                            showinfo: 0,
                            iv_load_policy: 3,
                            modestbranding: 1,
                            disablekb: 1,
                            playsinline: 1,
                            widget_referrer: window ? window.location.href : null,
                            cc_load_policy: e.captions.active ? 1 : 0,
                            cc_lang_pref: e.config.captions.language
                        },
                        events: {
                            onError: function(t) {
                                if (!e.media.error) {
                                    var i = t.data,
                                        n = {
                                            2: "The request contains an invalid parameter value. For example, this error occurs if you specify a video ID that does not have 11 characters, or if the video ID contains invalid characters, such as exclamation points or asterisks.",
                                            5: "The requested content cannot be played in an HTML5 player or another error related to the HTML5 player has occurred.",
                                            100: "The video requested was not found. This error occurs when a video has been removed (for any reason) or has been marked as private.",
                                            101: "The owner of the requested video does not allow it to be played in embedded players.",
                                            150: "The owner of the requested video does not allow it to be played in embedded players."
                                        }[i] || "An unknown error occured";
                                    e.media.error = {
                                        code: i,
                                        message: n
                                    }, f.call(e, e.media, "error")
                                }
                            },
                            onPlaybackRateChange: function(t) {
                                var i = t.target;
                                e.media.playbackRate = i.getPlaybackRate(), f.call(e, e.media, "ratechange")
                            },
                            onReady: function(t) {
                                if (!l.function(e.media.play)) {
                                    var i = t.target;
                                    Me.getTitle.call(e, s), e.media.play = function() {
                                        Pe.call(e, !0), i.playVideo()
                                    }, e.media.pause = function() {
                                        Pe.call(e, !1), i.pauseVideo()
                                    }, e.media.stop = function() {
                                        i.stopVideo()
                                    }, e.media.duration = i.getDuration(), e.media.paused = !0, e.media.currentTime = 0, Object.defineProperty(e.media, "currentTime", {
                                        get: function() {
                                            return Number(i.getCurrentTime())
                                        },
                                        set: function(t) {
                                            e.paused && !e.embed.hasPlayed && e.embed.mute(), e.media.seeking = !0, f.call(e, e.media, "seeking"), i.seekTo(t)
                                        }
                                    }), Object.defineProperty(e.media, "playbackRate", {
                                        get: function() {
                                            return i.getPlaybackRate()
                                        },
                                        set: function(e) {
                                            i.setPlaybackRate(e)
                                        }
                                    });
                                    var n = e.config.volume;
                                    Object.defineProperty(e.media, "volume", {
                                        get: function() {
                                            return n
                                        },
                                        set: function(t) {
                                            n = t, i.setVolume(100 * n), f.call(e, e.media, "volumechange")
                                        }
                                    });
                                    var a = e.config.muted;
                                    Object.defineProperty(e.media, "muted", {
                                        get: function() {
                                            return a
                                        },
                                        set: function(t) {
                                            var n = l.boolean(t) ? t : a;
                                            a = n, i[n ? "mute" : "unMute"](), f.call(e, e.media, "volumechange")
                                        }
                                    }), Object.defineProperty(e.media, "currentSrc", {
                                        get: function() {
                                            return i.getVideoUrl()
                                        }
                                    }), Object.defineProperty(e.media, "ended", {
                                        get: function() {
                                            return e.currentTime === e.duration
                                        }
                                    }), e.options.speed = i.getAvailablePlaybackRates(), e.supported.ui && e.media.setAttribute("tabindex", -1), f.call(e, e.media, "timeupdate"), f.call(e, e.media, "durationchange"), clearInterval(e.timers.buffering), e.timers.buffering = setInterval(function() {
                                        e.media.buffered = i.getVideoLoadedFraction(), (null === e.media.lastBuffered || e.media.lastBuffered < e.media.buffered) && f.call(e, e.media, "progress"), e.media.lastBuffered = e.media.buffered, 1 === e.media.buffered && (clearInterval(e.timers.buffering), f.call(e, e.media, "canplaythrough"))
                                    }, 200), setTimeout(function() {
                                        return be.build.call(e)
                                    }, 50)
                                }
                            },
                            onStateChange: function(t) {
                                var i = t.target;
                                switch (clearInterval(e.timers.playing), e.media.seeking && [1, 2].includes(t.data) && (e.media.seeking = !1, f.call(e, e.media, "seeked")), t.data) {
                                    case -1:
                                        f.call(e, e.media, "timeupdate"), e.media.buffered = i.getVideoLoadedFraction(), f.call(e, e.media, "progress");
                                        break;
                                    case 0:
                                        Pe.call(e, !1), e.media.loop ? (i.stopVideo(), i.playVideo()) : f.call(e, e.media, "ended");
                                        break;
                                    case 1:
                                        e.media.paused && !e.embed.hasPlayed ? e.media.pause() : (Pe.call(e, !0), f.call(e, e.media, "playing"), e.timers.playing = setInterval(function() {
                                            f.call(e, e.media, "timeupdate")
                                        }, 50), e.media.duration !== i.getDuration() && (e.media.duration = i.getDuration(), f.call(e, e.media, "durationchange")));
                                        break;
                                    case 2:
                                        e.muted || e.embed.unMute(), Pe.call(e, !1)
                                }
                                f.call(e, e.elements.container, "statechange", !1, {
                                    code: t.data
                                })
                            }
                        }
                    })
                }
            }
        },
        Ne = {
            setup: function() {
                this.media ? (M(this.elements.container, this.config.classNames.type.replace("{0}", this.type), !0), M(this.elements.container, this.config.classNames.provider.replace("{0}", this.provider), !0), this.isEmbed && M(this.elements.container, this.config.classNames.type.replace("{0}", "video"), !0), this.isVideo && (this.elements.wrapper = w("div", {
                    class: this.config.classNames.video
                }), b(this.media, this.elements.wrapper), this.elements.poster = w("div", {
                    class: this.config.classNames.poster
                }), this.elements.wrapper.appendChild(this.elements.poster)), this.isHTML5 ? U.extend.call(this) : this.isYouTube ? Me.setup.call(this) : this.isVimeo && Ce.setup.call(this)) : this.debug.warn("No media element found!")
            }
        },
        Le = function() {
            function e(t) {
                var i = this;
                m(this, e), this.player = t, this.publisherId = t.config.ads.publisherId, this.playing = !1, this.initialized = !1, this.elements = {
                    container: null,
                    displayContainer: null
                }, this.manager = null, this.loader = null, this.cuePoints = null, this.events = {}, this.safetyTimer = null, this.countdownTimer = null, this.managerPromise = new Promise(function(e, t) {
                    i.on("loaded", e), i.on("error", t)
                }), this.load()
            }
            return g(e, [{
                key: "load",
                value: function() {
                    var e = this;
                    this.enabled && (l.object(window.google) && l.object(window.google.ima) ? this.ready() : Ae(this.player.config.urls.googleIMA.sdk).then(function() {
                        e.ready()
                    }).catch(function() {
                        e.trigger("error", new Error("Google IMA SDK failed to load"))
                    }))
                }
            }, {
                key: "ready",
                value: function() {
                    var e = this;
                    this.startSafetyTimer(12e3, "ready()"), this.managerPromise.then(function() {
                        e.clearSafetyTimer("onAdsManagerLoaded()")
                    }), this.listeners(), this.setupIMA()
                }
            }, {
                key: "setupIMA",
                value: function() {
                    this.elements.container = w("div", {
                        class: this.player.config.classNames.ads
                    }), this.player.elements.container.appendChild(this.elements.container), google.ima.settings.setVpaidMode(google.ima.ImaSdkSettings.VpaidMode.ENABLED), google.ima.settings.setLocale(this.player.config.ads.language), this.elements.displayContainer = new google.ima.AdDisplayContainer(this.elements.container), this.requestAds()
                }
            }, {
                key: "requestAds",
                value: function() {
                    var e = this,
                        t = this.player.elements.container;
                    try {
                        this.loader = new google.ima.AdsLoader(this.elements.displayContainer), this.loader.addEventListener(google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED, function(t) {
                            return e.onAdsManagerLoaded(t)
                        }, !1), this.loader.addEventListener(google.ima.AdErrorEvent.Type.AD_ERROR, function(t) {
                            return e.onAdError(t)
                        }, !1);
                        var i = new google.ima.AdsRequest;
                        i.adTagUrl = this.tagUrl, i.linearAdSlotWidth = t.offsetWidth, i.linearAdSlotHeight = t.offsetHeight, i.nonLinearAdSlotWidth = t.offsetWidth, i.nonLinearAdSlotHeight = t.offsetHeight, i.forceNonLinearFullSlot = !1, i.setAdWillPlayMuted(!this.player.muted), this.loader.requestAds(i)
                    } catch (e) {
                        this.onAdError(e)
                    }
                }
            }, {
                key: "pollCountdown",
                value: function() {
                    var e = this;
                    if (!(arguments.length > 0 && void 0 !== arguments[0] && arguments[0])) return clearInterval(this.countdownTimer), void this.elements.container.removeAttribute("data-badge-text");
                    this.countdownTimer = setInterval(function() {
                        var t = ae(Math.max(e.manager.getRemainingTime(), 0)),
                            i = X("advertisement", e.player.config) + " - " + t;
                        e.elements.container.setAttribute("data-badge-text", i)
                    }, 100)
                }
            }, {
                key: "onAdsManagerLoaded",
                value: function(e) {
                    var t = this;
                    if (this.enabled) {
                        var i = new google.ima.AdsRenderingSettings;
                        i.restoreCustomPlaybackStateOnAdBreakComplete = !0, i.enablePreloading = !0, this.manager = e.getAdsManager(this.player, i), this.cuePoints = this.manager.getCuePoints(), l.empty(this.cuePoints) || this.cuePoints.forEach(function(e) {
                            if (0 !== e && -1 !== e && e < t.player.duration) {
                                var i = t.player.elements.progress;
                                if (l.element(i)) {
                                    var n = 100 / t.player.duration * e,
                                        s = w("span", {
                                            class: t.player.config.classNames.cues
                                        });
                                    s.style.left = n.toString() + "%", i.appendChild(s)
                                }
                            }
                        }), this.manager.setVolume(this.player.volume), this.manager.addEventListener(google.ima.AdErrorEvent.Type.AD_ERROR, function(e) {
                            return t.onAdError(e)
                        }), Object.keys(google.ima.AdEvent.Type).forEach(function(e) {
                            t.manager.addEventListener(google.ima.AdEvent.Type[e], function(e) {
                                return t.onAdEvent(e)
                            })
                        }), this.trigger("loaded")
                    }
                }
            }, {
                key: "onAdEvent",
                value: function(e) {
                    var t = this,
                        i = this.player.elements.container,
                        n = e.getAd(),
                        s = function(e) {
                            var i = "ads" + e.replace(/_/g, "").toLowerCase();
                            f.call(t.player, t.player.media, i)
                        };
                    switch (e.type) {
                        case google.ima.AdEvent.Type.LOADED:
                            this.trigger("loaded"), s(e.type), this.pollCountdown(!0), n.isLinear() || (n.width = i.offsetWidth, n.height = i.offsetHeight);
                            break;
                        case google.ima.AdEvent.Type.ALL_ADS_COMPLETED:
                            s(e.type), this.loadAds();
                            break;
                        case google.ima.AdEvent.Type.CONTENT_PAUSE_REQUESTED:
                            s(e.type), this.pauseContent();
                            break;
                        case google.ima.AdEvent.Type.CONTENT_RESUME_REQUESTED:
                            s(e.type), this.pollCountdown(), this.resumeContent();
                            break;
                        case google.ima.AdEvent.Type.STARTED:
                        case google.ima.AdEvent.Type.MIDPOINT:
                        case google.ima.AdEvent.Type.COMPLETE:
                        case google.ima.AdEvent.Type.IMPRESSION:
                        case google.ima.AdEvent.Type.CLICK:
                            s(e.type)
                    }
                }
            }, {
                key: "onAdError",
                value: function(e) {
                    this.cancel(), this.player.debug.warn("Ads error", e)
                }
            }, {
                key: "listeners",
                value: function() {
                    var e = this,
                        t = this.player.elements.container,
                        i = void 0;
                    this.player.on("ended", function() {
                        e.loader.contentComplete()
                    }), this.player.on("seeking", function() {
                        return i = e.player.currentTime
                    }), this.player.on("seeked", function() {
                        var t = e.player.currentTime;
                        l.empty(e.cuePoints) || e.cuePoints.forEach(function(n, s) {
                            i < n && n < t && (e.manager.discardAdBreak(), e.cuePoints.splice(s, 1))
                        })
                    }), window.addEventListener("resize", function() {
                        e.manager && e.manager.resize(t.offsetWidth, t.offsetHeight, google.ima.ViewMode.NORMAL)
                    })
                }
            }, {
                key: "play",
                value: function() {
                    var e = this,
                        t = this.player.elements.container;
                    this.managerPromise || this.resumeContent(), this.managerPromise.then(function() {
                        e.elements.displayContainer.initialize();
                        try {
                            e.initialized || (e.manager.init(t.offsetWidth, t.offsetHeight, google.ima.ViewMode.NORMAL), e.manager.start()), e.initialized = !0
                        } catch (t) {
                            e.onAdError(t)
                        }
                    }).catch(function() {})
                }
            }, {
                key: "resumeContent",
                value: function() {
                    this.elements.container.style.zIndex = "", this.playing = !1, this.player.currentTime < this.player.duration && this.player.play()
                }
            }, {
                key: "pauseContent",
                value: function() {
                    this.elements.container.style.zIndex = 3, this.playing = !0, this.player.pause()
                }
            }, {
                key: "cancel",
                value: function() {
                    this.initialized && this.resumeContent(), this.trigger("error"), this.loadAds()
                }
            }, {
                key: "loadAds",
                value: function() {
                    var e = this;
                    this.managerPromise.then(function() {
                        e.manager && e.manager.destroy(), e.managerPromise = new Promise(function(t) {
                            e.on("loaded", t), e.player.debug.log(e.manager)
                        }), e.requestAds()
                    }).catch(function() {})
                }
            }, {
                key: "trigger",
                value: function(e) {
                    for (var t = this, i = arguments.length, n = Array(i > 1 ? i - 1 : 0), s = 1; s < i; s++) n[s - 1] = arguments[s];
                    var a = this.events[e];
                    l.array(a) && a.forEach(function(e) {
                        l.function(e) && e.apply(t, n)
                    })
                }
            }, {
                key: "on",
                value: function(e, t) {
                    return l.array(this.events[e]) || (this.events[e] = []), this.events[e].push(t), this
                }
            }, {
                key: "startSafetyTimer",
                value: function(e, t) {
                    var i = this;
                    this.player.debug.log("Safety timer invoked from: " + t), this.safetyTimer = setTimeout(function() {
                        i.cancel(), i.clearSafetyTimer("startSafetyTimer()")
                    }, e)
                }
            }, {
                key: "clearSafetyTimer",
                value: function(e) {
                    l.nullOrUndefined(this.safetyTimer) || (this.player.debug.log("Safety timer cleared from: " + e), clearTimeout(this.safetyTimer), this.safetyTimer = null)
                }
            }, {
                key: "enabled",
                get: function() {
                    return this.player.isHTML5 && this.player.isVideo && this.player.config.ads.enabled && !l.empty(this.publisherId)
                }
            }, {
                key: "tagUrl",
                get: function() {
                    return "https://go.aniview.com/api/adserver6/vast/?" + le({
                        AV_PUBLISHERID: "58c25bb0073ef448b1087ad6",
                        AV_CHANNELID: "5a0458dc28a06145e4519d21",
                        AV_URL: window.location.hostname,
                        cb: Date.now(),
                        AV_WIDTH: 640,
                        AV_HEIGHT: 480,
                        AV_CDIM2: this.publisherId
                    })
                }
            }]), e
        }(),
        xe = {
            insertElements: function(e, t) {
                var i = this;
                l.string(t) ? T(e, this.media, {
                    src: t
                }) : l.array(t) && t.forEach(function(t) {
                    T(e, i.media, t)
                })
            },
            change: function(e) {
                var t = this;
                W(e, "sources.length") ? (U.cancelRequests.call(this), this.destroy.call(this, function() {
                    t.options.quality = [], A(t.media), t.media = null, l.element(t.elements.container) && t.elements.container.removeAttribute("class");
                    var i = e.sources,
                        n = e.type,
                        s = v(i, 1)[0],
                        a = s.provider,
                        o = void 0 === a ? de.html5 : a,
                        r = s.src,
                        c = "html5" === o ? n : "div",
                        u = "html5" === o ? {} : {
                            src: r
                        };
                    Object.assign(t, {
                        provider: o,
                        type: n,
                        supported: F.check(n, o, t.config.playsinline),
                        media: w(c, u)
                    }), t.elements.container.appendChild(t.media), l.boolean(e.autoplay) && (t.config.autoplay = e.autoplay), t.isHTML5 && (t.config.crossorigin && t.media.setAttribute("crossorigin", ""), t.config.autoplay && t.media.setAttribute("autoplay", ""), l.empty(e.poster) || (t.poster = e.poster), t.config.loop.active && t.media.setAttribute("loop", ""), t.config.muted && t.media.setAttribute("muted", ""), t.config.playsinline && t.media.setAttribute("playsinline", "")), be.addStyleHook.call(t), t.isHTML5 && xe.insertElements.call(t, "source", i), t.config.title = e.title, Ne.setup.call(t), t.isHTML5 && ("tracks" in e && xe.insertElements.call(t, "track", e.tracks), t.media.load()), (t.isHTML5 || t.isEmbed && !t.supported.ui) && be.build.call(t), t.fullscreen.update()
                }, !0)) : this.debug.warn("Invalid source format")
            }
        },
        _e = function() {
            function e(t, i) {
                var n = this;
                if (m(this, e), this.timers = {}, this.ready = !1, this.loading = !1, this.failed = !1, this.touch = F.touch, this.media = t, l.string(this.media) && (this.media = document.querySelectorAll(this.media)), (window.jQuery && this.media instanceof jQuery || l.nodeList(this.media) || l.array(this.media)) && (this.media = this.media[0]), this.config = K({}, ue, e.defaults, i || {}, function() {
                        try {
                            return JSON.parse(n.media.getAttribute("data-plyr-config"))
                        } catch (e) {
                            return {}
                        }
                    }()), this.elements = {
                        container: null,
                        captions: null,
                        buttons: {},
                        display: {},
                        progress: {},
                        inputs: {},
                        settings: {
                            popup: null,
                            menu: null,
                            panels: {},
                            buttons: {}
                        }
                    }, this.captions = {
                        active: null,
                        currentTrack: -1,
                        meta: new WeakMap
                    }, this.fullscreen = {
                        active: !1
                    }, this.options = {
                        speed: [],
                        quality: []
                    }, this.debug = new fe(this.config.debug), this.debug.log("Config", this.config), this.debug.log("Support", F), !l.nullOrUndefined(this.media) && l.element(this.media))
                    if (this.media.plyr) this.debug.warn("Target already setup");
                    else if (this.config.enabled)
                    if (F.check().api) {
                        var s = this.media.cloneNode(!0);
                        s.autoplay = !1, this.elements.original = s;
                        var a = this.media.tagName.toLowerCase(),
                            o = null,
                            r = null;
                        switch (a) {
                            case "div":
                                if (o = this.media.querySelector("iframe"), l.element(o)) {
                                    if (r = re(o.getAttribute("src")), this.provider = function(e) {
                                            return /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/.test(e) ? de.youtube : /^https?:\/\/player.vimeo.com\/video\/\d{0,9}(?=\b|\/)/.test(e) ? de.vimeo : null
                                        }(r.toString()), this.elements.container = this.media, this.media = o, this.elements.container.className = "", r.search.length) {
                                        var c = ["1", "true"];
                                        c.includes(r.searchParams.get("autoplay")) && (this.config.autoplay = !0), c.includes(r.searchParams.get("loop")) && (this.config.loop.active = !0), this.isYouTube ? (this.config.playsinline = c.includes(r.searchParams.get("playsinline")), this.config.hl = r.searchParams.get("hl")) : this.config.playsinline = !0
                                    }
                                } else this.provider = this.media.getAttribute(this.config.attributes.embed.provider), this.media.removeAttribute(this.config.attributes.embed.provider);
                                if (l.empty(this.provider) || !Object.keys(de).includes(this.provider)) return void this.debug.error("Setup failed: Invalid provider");
                                this.type = he.video;
                                break;
                            case "video":
                            case "audio":
                                this.type = a, this.provider = de.html5, this.media.hasAttribute("crossorigin") && (this.config.crossorigin = !0), this.media.hasAttribute("autoplay") && (this.config.autoplay = !0), (this.media.hasAttribute("playsinline") || this.media.hasAttribute("webkit-playsinline")) && (this.config.playsinline = !0), this.media.hasAttribute("muted") && (this.config.muted = !0), this.media.hasAttribute("loop") && (this.config.loop.active = !0);
                                break;
                            default:
                                return void this.debug.error("Setup failed: unsupported type")
                        }
                        this.supported = F.check(this.type, this.provider, this.config.playsinline), this.supported.api ? (this.eventListeners = [], this.listeners = new ke(this), this.storage = new Z(this), this.media.plyr = this, l.element(this.elements.container) || (this.elements.container = w("div"), b(this.media, this.elements.container)), be.addStyleHook.call(this), Ne.setup.call(this), this.config.debug && d.call(this, this.elements.container, this.config.events.join(" "), function(e) {
                            n.debug.log("event: " + e.type)
                        }), (this.isHTML5 || this.isEmbed && !this.supported.ui) && be.build.call(this), this.listeners.container(), this.listeners.global(), this.fullscreen = new ye(this), this.config.ads.enabled && (this.ads = new Le(this)), this.config.autoplay && this.play()) : this.debug.error("Setup failed: no support")
                    } else this.debug.error("Setup failed: no support");
                else this.debug.error("Setup failed: disabled by config");
                else this.debug.error("Setup failed: no suitable element passed")
            }
            return g(e, [{
                key: "play",
                value: function() {
                    return l.function(this.media.play) ? this.media.play() : null
                }
            }, {
                key: "pause",
                value: function() {
                    this.playing && l.function(this.media.pause) && this.media.pause()
                }
            }, {
                key: "togglePlay",
                value: function(e) {
                    (l.boolean(e) ? e : !this.playing) ? this.play(): this.pause()
                }
            }, {
                key: "stop",
                value: function() {
                    this.isHTML5 ? (this.pause(), this.restart()) : l.function(this.media.stop) && this.media.stop()
                }
            }, {
                key: "restart",
                value: function() {
                    this.currentTime = 0
                }
            }, {
                key: "rewind",
                value: function(e) {
                    this.currentTime = this.currentTime - (l.number(e) ? e : this.config.seekTime)
                }
            }, {
                key: "forward",
                value: function(e) {
                    this.currentTime = this.currentTime + (l.number(e) ? e : this.config.seekTime)
                }
            }, {
                key: "increaseVolume",
                value: function(e) {
                    var t = this.media.muted ? 0 : this.volume;
                    this.volume = t + (l.number(e) ? e : 0)
                }
            }, {
                key: "decreaseVolume",
                value: function(e) {
                    this.increaseVolume(-e)
                }
            }, {
                key: "toggleCaptions",
                value: function(e) {
                    ce.toggle.call(this, e, !1)
                }
            }, {
                key: "airplay",
                value: function() {
                    F.airplay && this.media.webkitShowPlaybackTargetPicker()
                }
            }, {
                key: "toggleControls",
                value: function(e) {
                    if (this.supported.ui && !this.isAudio) {
                        var t = N(this.elements.container, this.config.classNames.hideControls),
                            i = void 0 === e ? void 0 : !e,
                            n = M(this.elements.container, this.config.classNames.hideControls, i);
                        if (n && this.config.controls.includes("settings") && !l.empty(this.config.settings) && oe.toggleMenu.call(this, !1), n !== t) {
                            var s = n ? "controlshidden" : "controlsshown";
                            f.call(this, this.media, s)
                        }
                        return !n
                    }
                    return !1
                }
            }, {
                key: "on",
                value: function(e, t) {
                    d.call(this, this.elements.container, e, t)
                }
            }, {
                key: "once",
                value: function(e, t) {
                    p.call(this, this.elements.container, e, t)
                }
            }, {
                key: "off",
                value: function(e, t) {
                    h(this.elements.container, e, t)
                }
            }, {
                key: "destroy",
                value: function(e) {
                    var t = this,
                        i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    if (this.ready) {
                        var n = function() {
                            document.body.style.overflow = "", t.embed = null, i ? (Object.keys(t.elements).length && (A(t.elements.buttons.play), A(t.elements.captions), A(t.elements.controls), A(t.elements.wrapper), t.elements.buttons.play = null, t.elements.captions = null, t.elements.controls = null, t.elements.wrapper = null), l.function(e) && e()) : (function() {
                                this && this.eventListeners && (this.eventListeners.forEach(function(e) {
                                    var t = e.element,
                                        i = e.type,
                                        n = e.callback,
                                        s = e.options;
                                    t.removeEventListener(i, n, s)
                                }), this.eventListeners = [])
                            }.call(t), C(t.elements.original, t.elements.container), f.call(t, t.elements.original, "destroyed", !0), l.function(e) && e.call(t.elements.original), t.ready = !1, setTimeout(function() {
                                t.elements = null, t.media = null
                            }, 200))
                        };
                        this.stop(), this.isHTML5 ? (clearTimeout(this.timers.loading), be.toggleNativeControls.call(this, !0), n()) : this.isYouTube ? (clearInterval(this.timers.buffering), clearInterval(this.timers.playing), null !== this.embed && l.function(this.embed.destroy) && this.embed.destroy(), n()) : this.isVimeo && (null !== this.embed && this.embed.unload().then(n), setTimeout(n, 200))
                    }
                }
            }, {
                key: "supports",
                value: function(e) {
                    return F.mime.call(this, e)
                }
            }, {
                key: "isHTML5",
                get: function() {
                    return Boolean(this.provider === de.html5)
                }
            }, {
                key: "isEmbed",
                get: function() {
                    return Boolean(this.isYouTube || this.isVimeo)
                }
            }, {
                key: "isYouTube",
                get: function() {
                    return Boolean(this.provider === de.youtube)
                }
            }, {
                key: "isVimeo",
                get: function() {
                    return Boolean(this.provider === de.vimeo)
                }
            }, {
                key: "isVideo",
                get: function() {
                    return Boolean(this.type === he.video)
                }
            }, {
                key: "isAudio",
                get: function() {
                    return Boolean(this.type === he.audio)
                }
            }, {
                key: "playing",
                get: function() {
                    return Boolean(this.ready && !this.paused && !this.ended)
                }
            }, {
                key: "paused",
                get: function() {
                    return Boolean(this.media.paused)
                }
            }, {
                key: "stopped",
                get: function() {
                    return Boolean(this.paused && 0 === this.currentTime)
                }
            }, {
                key: "ended",
                get: function() {
                    return Boolean(this.media.ended)
                }
            }, {
                key: "currentTime",
                set: function(e) {
                    if (this.duration) {
                        var t = l.number(e) && e > 0;
                        this.media.currentTime = t ? Math.min(e, this.duration) : 0, this.debug.log("Seeking to " + this.currentTime + " seconds")
                    }
                },
                get: function() {
                    return Number(this.media.currentTime)
                }
            }, {
                key: "buffered",
                get: function() {
                    var e = this.media.buffered;
                    return l.number(e) ? e : e && e.length && this.duration > 0 ? e.end(0) / this.duration : 0
                }
            }, {
                key: "seeking",
                get: function() {
                    return Boolean(this.media.seeking)
                }
            }, {
                key: "duration",
                get: function() {
                    var e = parseFloat(this.config.duration),
                        t = (this.media || {}).duration,
                        i = l.number(t) && t !== 1 / 0 ? t : 0;
                    return e || i
                }
            }, {
                key: "volume",
                set: function(e) {
                    var t = e;
                    l.string(t) && (t = Number(t)), l.number(t) || (t = this.storage.get("volume")), l.number(t) || (t = this.config.volume), t > 1 && (t = 1), t < 0 && (t = 0), this.config.volume = t, this.media.volume = t, !l.empty(e) && this.muted && t > 0 && (this.muted = !1)
                },
                get: function() {
                    return Number(this.media.volume)
                }
            }, {
                key: "muted",
                set: function(e) {
                    var t = e;
                    l.boolean(t) || (t = this.storage.get("muted")), l.boolean(t) || (t = this.config.muted), this.config.muted = t, this.media.muted = t
                },
                get: function() {
                    return Boolean(this.media.muted)
                }
            }, {
                key: "hasAudio",
                get: function() {
                    return !this.isHTML5 || (!!this.isAudio || (Boolean(this.media.mozHasAudio) || Boolean(this.media.webkitAudioDecodedByteCount) || Boolean(this.media.audioTracks && this.media.audioTracks.length)))
                }
            }, {
                key: "speed",
                set: function(e) {
                    var t = null;
                    l.number(e) && (t = e), l.number(t) || (t = this.storage.get("speed")), l.number(t) || (t = this.config.speed.selected), t < .1 && (t = .1), t > 2 && (t = 2), this.config.speed.options.includes(t) ? (this.config.speed.selected = t, this.media.playbackRate = t) : this.debug.warn("Unsupported speed (" + t + ")")
                },
                get: function() {
                    return Number(this.media.playbackRate)
                }
            }, {
                key: "quality",
                set: function(e) {
                    var t = this.config.quality,
                        i = this.options.quality;
                    if (i.length) {
                        var n = [!l.empty(e) && Number(e), this.storage.get("quality"), t.selected, t.default].find(l.number);
                        if (!i.includes(n)) {
                            var s = function(e, t) {
                                return l.array(e) && e.length ? e.reduce(function(e, i) {
                                    return Math.abs(i - t) < Math.abs(e - t) ? i : e
                                }) : null
                            }(i, n);
                            this.debug.warn("Unsupported quality option: " + n + ", using " + s + " instead"), n = s
                        }
                        t.selected = n, this.media.quality = n
                    }
                },
                get: function() {
                    return this.media.quality
                }
            }, {
                key: "loop",
                set: function(e) {
                    var t = l.boolean(e) ? e : this.config.loop.active;
                    this.config.loop.active = t, this.media.loop = t
                },
                get: function() {
                    return Boolean(this.media.loop)
                }
            }, {
                key: "source",
                set: function(e) {
                    xe.change.call(this, e)
                },
                get: function() {
                    return this.media.currentSrc
                }
            }, {
                key: "poster",
                set: function(e) {
                    this.isVideo ? be.setPoster.call(this, e, !1).catch(function() {}) : this.debug.warn("Poster can only be set for video")
                },
                get: function() {
                    return this.isVideo ? this.media.getAttribute("poster") : null
                }
            }, {
                key: "autoplay",
                set: function(e) {
                    var t = l.boolean(e) ? e : this.config.autoplay;
                    this.config.autoplay = t
                },
                get: function() {
                    return Boolean(this.config.autoplay)
                }
            }, {
                key: "currentTrack",
                set: function(e) {
                    ce.set.call(this, e, !1)
                },
                get: function() {
                    var e = this.captions,
                        t = e.toggled,
                        i = e.currentTrack;
                    return t ? i : -1
                }
            }, {
                key: "language",
                set: function(e) {
                    ce.setLanguage.call(this, e, !1)
                },
                get: function() {
                    return (ce.getCurrentTrack.call(this) || {}).language
                }
            }, {
                key: "pip",
                set: function(e) {
                    var t = "picture-in-picture",
                        i = "inline";
                    if (F.pip) {
                        var n = l.boolean(e) ? e : this.pip === i;
                        this.media.webkitSetPresentationMode(n ? t : i)
                    }
                },
                get: function() {
                    return F.pip ? this.media.webkitPresentationMode : null
                }
            }], [{
                key: "supported",
                value: function(e, t, i) {
                    return F.check(e, t, i)
                }
            }, {
                key: "loadSprite",
                value: function(e, t) {
                    return te(e, t)
                }
            }, {
                key: "setup",
                value: function(t) {
                    var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        n = null;
                    return l.string(t) ? n = Array.from(document.querySelectorAll(t)) : l.nodeList(t) ? n = Array.from(t) : l.array(t) && (n = t.filter(l.element)), l.empty(n) ? null : n.map(function(t) {
                        return new e(t, i)
                    })
                }
            }]), e
        }();
    return _e.defaults = (Se = ue, JSON.parse(JSON.stringify(Se))), _e
});
